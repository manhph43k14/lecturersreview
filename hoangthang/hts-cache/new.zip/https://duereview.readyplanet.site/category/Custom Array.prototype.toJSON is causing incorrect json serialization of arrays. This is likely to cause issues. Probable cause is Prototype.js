<!DOCTYPE html>
<html
    lang=""
    xml:lang=""
    xmlns:og="http://ogp.me/ns#"
    xmlns:fb="http://ogp.me/ns/fb#"
    style="background-color: #888;"
    >
    <head>
        <title></title>
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=IE7" />
        <meta charset="utf-8" />
        <link href="/images/favicons/favicon.png?1581928055"  rel="apple-touch-icon"  />
<link href="/images/favicons/favicon60.png?1581928055"  rel="apple-touch-icon" sizes="60x60" />
<link href="/images/favicons/favicon76.png?1581928055"  rel="apple-touch-icon" sizes="76x76" />
<link href="/images/favicons/favicon120.png?1581928055"  rel="apple-touch-icon" sizes="120x120" />
<link href="/images/favicons/favicon152.png?1581928055"  rel="apple-touch-icon" sizes="152x152" />
            <link rel="canonical" href="https://w54023503.readyplanet.site/product/Custom+Array.prototype.toJSON+is+causing+incorrect+json+serialization+of+arrays.+This+is+likely+to+cause+issues.+Probable+cause+is+Prototype.js" />
                        <meta name="viewport" content="initial-scale=1.0">
        <style>
@font-face {
				font-family: 'kanit';
				font-weight: normal;
        font-style:  normal;
        font-display: swap;
				src: url('/modules/flexi/fonts/kanit-webfont.ttf'); /* IE9 Compat Modes */
				src: local('kanit'),
				url('/modules/flexi/fonts/kanit-webfont.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
				url('/modules/flexi/fonts/kanit-webfont.woff') format('woff'), /* Modern browsers */
				url('/modules/flexi/fonts/kanit-webfont.ttf') format('truetype'); /* Safari, Android, iOS */
			}

			@font-face {
				font-family: 'RSU';
				font-weight: normal;
        font-style:  normal;
        font-display: swap;
				src: url('/modules/flexi/fonts/rsu_regular-webfont.ttf'); /* IE9 Compat Modes */
				src: local('RSU'),
				url('/modules/flexi/fonts/rsu_regular-webfont.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
				url('/modules/flexi/fonts/rsu_regular-webfont.woff') format('woff'), /* Modern browsers */
				url('/modules/flexi/fonts/rsu_regular-webfont.ttf') format('truetype'); /* Safari, Android, iOS */
			}

			body {
                height: 100%;
                margin: 0;
                padding: 0px 0px 0px 0px;
                font-size: 14px;
                font-weight: normal;
            }
            #body-bg {
                width: 100%;
                min-height: 100%;
                height: auto;
            }
            ul, li {
                padding: 0;
                margin: 0;
            }
            #wrapper {
                margin: 0px auto;
                padding: 0;
                width: 100%;
                height: 100%;
                position: relative;
            }
            #content {
                padding: 0px;
                overflow: visible;
                position: relative;
            }
			#content .album-images > ul > li .image-wrapper {
			    height: 152px;
			    line-height: 152px;
			    margin: auto;
			    text-align: center;
			    width: 260px;
			}
            .back-to-top {
                display: none;
            }
#header .header-inner .panel #header-images>ul>li>.image-wrapper>img{
max-width:100%;
max-height:100%;
vertical-align:middle;
}

            #header .header-inner .panel #header-images>ul>li>.image-wrapper>img.no-image {
                visibility: hidden;
            }
			.ready-template-section-generic-bg {
				overflow: hidden;
				min-height: 200px;
				background-size: cover;
				background-position: center;
				margin: 10px 0px 12px 0px;
				position: relative;
			}

			.product-detail-bottom .product-detail-stock-have-not-enough .stock-have-not-enough {
					display: none;
			}
            
		#header #topbar {
		  position: relative;
		  top: 0;
		  left: 0;
		  margin: 0px;
		  width: 100%;
		  display: table;
		}
		#header #topbar div.nav-topbar-logo {
		  max-width: 15%;
		  text-align: center;
		}
		#header #topbar div.nav-topbar-logo a {
		  display: block;
		}
		#header #topbar div.nav-topbar-logo a img {
		  max-width: 100%;
		}
		#header #topbar .topbar-sub-container {
		  display: table-row;
		}
		#header #topbar .topbar-sub-container > div {
		  display: table-cell;
		}
		#header #topbar .topbar-sub-container .topnav-container {
		  vertical-align: middle;
		}
		#header #topbar ul.top-menu-position-right {
		  float: right;
		  width: auto;
		}
		#header #topbar ul.top-menu-position-center {
		  text-align: center;
		}
		#header #topbar ul.top-menu-position-center > li > ul {
		  text-align: left;
		}
		#header #topbar.sticky {
		  position: fixed !important;
		  top: 0;
		  left: 0;
		}
		#header #topbar.topbar-logo-small.topbar-logo-active .topbar-sub-container {
		  max-width: 93%;
		}
		#header #topbar.topbar-logo-small.topbar-logo-active .topbar-sub-container .nav-topbar-logo {
		  width: 5%;
		}
		#header #topbar.topbar-logo-medium.topbar-logo-active .topbar-sub-container {
		  max-width: 90.5%;
		}
		#header #topbar.topbar-logo-medium.topbar-logo-active .topbar-sub-container .nav-topbar-logo {
		  width: 7.5%;
		}
		#header #topbar.topbar-logo-large.topbar-logo-active .topbar-sub-container {
		  max-width: 83%;
		}
		#header #topbar.topbar-logo-large.topbar-logo-active .topbar-sub-container .nav-topbar-logo {
		  width: 15%;
		}
        #header #topbar ul.topnav > li:not(.nav-add-button) {
            border-radius: 5px;
        }
		ul.topnav {
		  list-style: none;
		  margin: auto;
		  padding: 0px;
		  width: 100%;
		  min-width: 12.5%;
		  max-width: 1200px;
		}
		ul.topnav > li {
		  display: inline-block;
		  vertical-align: top;
		  margin: 3px;
		  padding: 0px 15px 0px 15px;
		  min-height: 35px;
		  position: relative;
		}
		ul.topnav > li.home i {
		  vertical-align: middle;
		}
		ul.topnav > li.hidden {
		  display: none;
		}
		ul.topnav > li > a {
		  float: left;
		  line-height: 1em;
		  padding: 10px 0px;
		  display: inline-block;
		  text-decoration: none;
		  white-space: nowrap;
		}
		ul.topnav > li > span {
		  margin: 3px -5px 3px 5px;
		  padding: 7px;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 0.5em !important;
		  text-decoration: none !important;
		}
		ul.topnav > li > ul.subnav {
            display: none;
            position: absolute;
		}
		.mobile-topbar {
		  height: 43px;
		  position: fixed;
		  top: 0;
		  width: 100%;
		  z-index: 15;
		  display: none;
		}
		.mobile-topbar .trigger-wrapper {
		  float: left;
		  text-align: center;
		  font-size: 32px;
		}
		.mobile-topbar .searchbox-wrapper {
		  float: right;
		  width: 42px;
		  height: 42px;
		  position: fixed;
		  right: 0;
		  overflow: hidden;
		}
		.mobile-topbar .searchbox-wrapper #mobile-searchbox-icon {
		  width: 42px;
		  text-align: center;
		  display: block;
		  float: right;
		  z-index: 15;
		}
		.mobile-topbar .searchbox-wrapper .search-form {
		  display: none;
		}
		.mobile-topbar .header-viewcart-box {
		  position: relative;
		  width: 42px;
		  float: left;
		}
		.mobile-topbar .header-viewcart-box .header-viewcart-order-total {
		  left: -5px;
		  padding: 3px;
		  position: absolute;
		  text-align: center;
		  top: 2px;
		  width: 16px;
		}
		#slidemenu-container #slidemenu-menu {
		  position: fixed;
		  width: 80%;
		  display: block;
		  overflow: hidden;
		  left: -80%;
		}
        .mobile-topbar .trigger-wrapper {
            float: left;
            height: 42px;
            text-align: center;
            width: 42px;
            font-size: 32px;
        }
	#header {
                position: relative;
                z-index: 2;
            }
            .clear {
                height: 0px;
                padding: 0px;
                margin: 0px;
                border: none;
                clear: both;
            }
            #header .header-inner {
                height: 100%;
                position: relative;
                width: 100%;
                line-height: 0;
            }
            #header .header-inner .panel-fill {
                display: inline-block;
            }
            .ready-template-panel {
                width: 100%;
                height: 100%;
                overflow: hidden;
                background-size: cover !important;
                background-position: top center !important;
                background-repeat: no-repeat;
            }
            .ready-template-panel .header-logo-position-center {
                margin: 0 auto;
                text-align: center;
            }
            .ready-template-panel .header-logo-position-left {
                float: left;
            }
            .ready-template-panel .header-logo-position-center {
                margin: 0 auto;
                text-align: center;
            }
            .ready-template-panel .header-logo-position-right {
                float: right;
            }
            template-panel .ready-template-header-logo {
                max-width: 80%;
            }
            #header > .header-inner > .panel {
                height: 100%;
                left: 0;
                top: 0;
                width: 100%;
                position: absolute;
            }
            #header #logo {
                float: left;
                width: 19.79%;
                max-width: 190px;
                margin-right: 0.52%;
                max-height: 150px;
            }
            #header .header-inner .panel #panel-background {
                display: inline-block;
                height: 100%;
                position: relative;
                width: 100%;
                z-index: 0;
            }
            #header .header-inner .panel #siteinfo {
                padding: 5px 0.52%;
                position: relative;
                overflow: hidden;
                max-height: 100%;
            }
            #header .header-inner .panel #header-images {
                padding-left: 0.31px;
                position: absolute;
                bottom: 10px;
                width: 100%;
            }
            #header .header-inner .panel #siteinfo #sitename {
                font-style: normal;
                text-decoration: none;
                text-align: left;
                margin: 5px 0%;
                padding: 0%;
                min-height: 40px;
                line-height: 1em;
            }
            #header .header-inner .panel #siteinfo #tagline {
                min-height: 28px;
                font-style: normal;
                text-decoration: none;
                text-align: left;
                margin: 5px 0%;
                padding: 0%;
                line-height: 1em;
                display: block;
}
                #header .header-inner .panel #header-images > ul{
                    list-style:none;
                    margin:0;
                    padding:0;
                    width:100%;
                }

                #header .header-inner .panel #header-images > ul > li{
                float:left;
                text-align:center;
                width:10%;
}
                #header .header-inner .panel #header-images > ul > li > .image-wrapper{
                    line-height:0px;
                }
                #header #logo a>img {
                    max-width: 100%;
                    vertical-align: middle;
                    max-height: 100%;
                }
            #sidebar {
        float: left;
        width: 18.75%;
        min-height: 600px;
        padding: 10px 0.52% 5px;
        color: #fff;
        background-color: #222;
        border-radius: 0px 0px 10px 0px;
        /* START: a fix for z-index bug in IE7, to allow the side subnav floating over the image area */
        z-index: 1;
        /* END: a fix for z-index bug in IE7 */
        behavior: url(/modules/helper/PIE/PIE.htc);
}
#sidebar ul.widgets {
list-style: none;
padding: 0px;
margin: 0px;
background-color: transparent;
clear: both;
/*--widget tag cloud--*/
}
#sidebar ul.widgets > li {
margin: 5px 0px;
width: 100%;
min-height: 35px;
text-align: center;
display: list-item;
background-color: transparent;
}
#sidebar ul.widgets > li.image-link {
max-width: 240px;
margin: auto;
}
#sidebar ul.widgets li.form input[type=text], #sidebar ul.widgets li.form textarea {
font-family: Tahoma, Arial, Helvetica, sans-serif;
font-size: 14px;
}
#sidebar ul.widgets li.image-link img {
width: 95.74%;
}
#sidebar ul.widgets .widget-item {
position: relative;
}
#sidebar ul.widgets li.html > .widget-item img, #sidebar ul.widgets li.html > .widget-item table, #sidebar ul.widgets li.html > .widget-item iframe, #sidebar ul.widgets li.html > .widget-item embed, #sidebar ul.widgets li.html > .widget-item object, #sidebar ul.widgets li.html > .widget-item div, #sidebar ul.widgets li.html > .widget-item ul, #sidebar ul.widgets li.html > .widget-item li, #sidebar ul.widgets li.html > .widget-item p, #sidebar ul.widgets li.html > .widget-item ol, #sidebar ul.widgets li.html > .widget-item form {
max-width: 100% !important;
}
#sidebar ul.widgets li.html > .widget-item table, #sidebar ul.widgets li.html > .widget-item iframe, #sidebar ul.widgets li.html > .widget-item div, #sidebar ul.widgets li.html > .widget-item ul, #sidebar ul.widgets li.html > .widget-item li, #sidebar ul.widgets li.html > .widget-item p, #sidebar ul.widgets li.html > .widget-item ol, #sidebar ul.widgets li.html > .widget-item form {
overflow: auto !important;
}
#sidebar ul.widgets li > .widget-item > .search-form .keyword {
background: url(/modules/flexi/images/readyplanet_search_engine.gif) no-repeat scroll left center #fff;
width: 100%;
margin: 0px 0px 5px 0px;
border: solid 1px #bbb;
border-radius: 4px;
height: 27px;
font-family: Tahoma, Arial, Helvetica, sans-serif;
font-size: 14px;
-moz-box-sizing: border-box;
-webkit-box-sizing: border-box;
box-sizing: border-box;
}
#sidebar ul.widgets > li > .widget-item > .search-form input[type=button] {
width: 100%;
border-radius: 5px;
border: none;
padding: 5px 10px;
}
#sidebar ul.widgets > li > .widget-item > .tag-cloud-widget-container .tag-cloud-show {
border-radius: 5px;
padding: 5px 10px;
}
#sidebar ul.widgets > li .widget-item .reCaptcha-container {
overflow: hidden;
}
#sidebar ul.widgets > li .widget-item .reCaptcha-container > div {
transform: scale(0.72);
-webkit-transform: scale(0.72);
transform-origin: 0 0;
-webkit-transform-origin: 0 0;
}
#sidebar ul.widgets > li .widget-item .reCaptcha-container > div > div {
width: 100% !important;
}
#sidebar ul.widgets ul.widgets > li.tag-cloud {
min-height: 250px;
overflow: hidden;
}
#sidebar ul.widgets ul.widgets > li.tag-cloud ul.tag-cloud {
text-align: left;
}
#sidebar ul.widgets ul.widgets > li.tag-cloud ul.tag-cloud > li a {
text-decoration: none;
}
#sidebar ul.widgets ul.widgets > li.tag-cloud ul.tag-cloud > li a:hover {
text-decoration: underline;
}
/*--widget best-sellers--*/
.widget-item > .best-sellers-container > h3 {
    font-size: 24px;
    margin: 5px 0;
    text-align: center;
}

.widget-item > .best-sellers-container > ol {
      text-align: left;
        padding-left: 30px;
}
.widget-item > .best-sellers-container li a:hover {
      text-decoration: underline !important;
}
/*--widget popular contents--*/
.widget-item > .popular-contents-container > h3 {
      font-size: 24px;
        margin: 5px 0;
        text-align: center;
}
.widget-item > .popular-contents-container ol {
      text-align: left;
        padding-left: 30px;
}
.widget-item > .popular-contents-container li a:hover {
      text-decoration: underline !important;
}
.widget-item > .popular-contents-container select {
      border: 1px solid #bbb;
        border-radius: 4px 4px 4px 4px;
        margin-bottom: 5px;
          width: 44.44%;
}

/*--widget member-login form--*/
.widget-item #member-login-wrap {
    padding: 15px 0;
}
.widget-item #member-login-wrap h3 {
    font-size: 24px;
    margin: 5px 0;
    text-align: center;
}
#facebook-icon-wrapper {
font-family: Tahoma, Arial, Helvetica, sans-serif;
font-size: 13px;
color: #ffffff;
padding: 0 10px 0 5px;
display: block;
line-height: 40px;
margin: 0 auto;
border: thin solid #3b5998;
border-radius: 5px;
font-weight: bold;
background-color: #3b5998;
overflow: hidden;
text-overflow: ellipsis;
width: 87%;
white-space: nowrap;
text-align: center;
}

#facebook-icon-wrapper i {
margin-right: 15px;
margin-left: 5px;
vertical-align: middle;
}
#facebook-icon-wrapper:hover {
background-color: #fff;
color: #3b5998;
}
#facebook-icon-wrapper:before {
content: '';
/* IE9 ellipsis fix */
}

.widget-item #member-login-wrap .facebook-login {
    text-align: center;
}
.widget-item #member-login-wrap .facebook-login a {
    text-decoration: none;
}
.widget-item #member-login-wrap .facebook-login img {
    width: 94.44%;
}
.widget-item #member-login-wrap ul li {
    list-style-type: none;
    min-height: 30px;
    padding: 5px;
    text-align: left;
}
.widget-item #member-login-wrap label {
    font-size: 14px;
    font-weight: normal;
    width: 66.67%;
}
.widget-item #member-login-wrap ul li select {
    border: 1px solid #bbb;
    border-radius: 4px 4px 4px 4px;
    width: 100%;
}
.widget-item #member-login-wrap ul li input[type=text], .widget-item #member-login-wrap ul li input[type=password] {
    border: 1px solid #bbb;
    border-radius: 4px 4px 4px 4px;
    height: 20px;
    width: 100%;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}

.widget-item .member-box .submit {
    display: inline;
}
.widget-item .member-box .submit #btn-login {
    margin-top: 10px;
}
.widget-item .member-box .signup {
    text-align: left;
}
.widget-item .member-box .signup > a {
    font-size: 14px;
    padding: 3px;
    margin: 3px 0;
    display: block;
    text-decoration: none;
}
.widget-item .member-box .signup > a:hover {
    text-decoration: none;
}
.widget-item .member-box input[type=button], .widget-item .member-box input[type=submit] {
    border-radius: 5px 5px 5px 5px;
    border: none;
    cursor: pointer;
    padding: 5px 10px;
    width: 100%;
}
.widget-item input, .widget-item select {
    font-family: Tahoma, Arial, sans-serif;
    font-size: 13px;
}
.widget-item #member-menu-wrap {
    display: block;
}
.widget-item #member-menu-wrap .member-menu-title {
    margin: 5px 0;
}
.widget-item #member-menu-wrap .member-menu-title img {
    /*vertical-align: middle;*/
    max-width: 100px;
    max-height: 100px;
}
.widget-item #member-menu-wrap .member-menu-title h3 {
    font-size: 24px;
    text-align: center;
    /*display: inline;*/
    vertical-align: middle;
}
.widget-item #member-menu-wrap ul {
    list-style-type: none;
    clear: both;
    padding: 5px;
}
.widget-item #member-menu-wrap ul > li {
    clear: both;
    /*float: left;*/
    /*background-color: #333;*/
    margin: 3px 0px;
    padding: 5px 5px 0px 5px;
    width: 98%;
    height: auto;
    min-height: 15px;
    text-align: left;
    display: list-item;
    position: relative;
    border-radius: 5px;
    behavior: url(/modules/helper/PIE/PIE.htc);
    overflow: visible;
}
.widget-item #member-menu-wrap ul > li:hover {
    /*background-color: #444;*/
    z-index: 1 !important;
    box-shadow: 5px 5px 7px rgba(0, 0, 0, 0.5);
    box-shadow: none ;
    /* disabled the box-shadow in IE8 */
    *box-shadow: none;
    /* disabled the box-shadow in IE7 */
}
.widget-item #member-menu-wrap ul > li > a {
    text-decoration: none;
    display: list-item;
    line-height: 1em;
    /*padding: 2px 20px;*/
}
.widget-item #member-menu-wrap ul > li > a:hover {
    text-decoration: none;
}
.widget-item #member-menu-wrap hr {
    border-bottom: 0px;
    clear: both;
}
.widget-item .form-icon {
    display: block;
    opacity: 0.6;
    right: 10%;
    /*top: 30.5px;*/
    bottom: 10px;
    font-size: 18px;
    color: #ccc;
    position: absolute;
}
/* START: View Cart Box */
.viewcart-box {
    padding: 5px;
    margin: 0px 0px 10px 0px;
    text-align: center;
    color: #fff;
    background-color: #444;
    adding-left: 30px;
    box-shadow: 5px 5px 7px rgba(0, 0, 0, 0.7);
    *filter: progid:DXImageTransform.Microsoft.Shadow(color='#000000', Direction=145, Strength=5);
}
.viewcart-box span {
    display: inline-block;
    width: 40%;
    vertical-align: middle;
}
.viewcart-box a {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    text-decoration: none;
}
.viewcart-box a:hover {
    color: #fed22f;
    text-decoration: underline;
}
#viewcart-box-no-sidebar {
  display: none;
  }
/** Side Nav & Hidden Nav **/
ul.sidenav, ul.hiddennav {
      float: left;
        list-style: none;
        padding: 0;
          margin: 0;
          background-color: transparent;
            min-height: 35px;
            /* This style is required to make the slideToggle effect works properly in IE7. */
            width: 100%;
}
ul.sidenav .subnav, ul.hiddennav .subnav {
      box-shadow: 5px 5px 7px rgba(0, 0, 0, 0.3);
}
ul.hiddennav {
      padding: 10px 0;
        min-width: 150px;
        display: none;
}
ul.sidenav > li, ul.hiddennav > li {
    clear: both;
    float: left;
    /* Instead of using overflow:hidden, float the main menu make its background color covers
     *    the long menu name with multiple lines, but also still allow the subnav to be displayed. */
    margin: 2px 0px;
    padding: 0px 13.89% 0px 5.55%;
    width: 80.55%;
    height: auto;
    min-height: 15px;
    text-align: left;
    display: list-item;
    position: relative;
    border-radius: 5px;
    behavior: url(/modules/helper/PIE/PIE.htc);
    overflow: visible;
    /* If it's overflow:hidden, the subnav will not be seen. */
}
.hiddennav-container > .header > .hiddennav-icon {
    float: left;
    font-size: 19px;
    margin: 2px 0px 3px 2px;
}
.hiddennav-container > .header > .hiddennav-header-title {
    margin-top: 5px;
    display: none;
}
ul.hiddennav > li {
    width: 78%;
    margin: 2px 2px;
}
ul.sidenav > li:hover, ul.hiddennav > li:hover {
    background-color: #444;
    z-index: 1 !important;
    box-shadow: none;
}
ul.sidenav > li > a, ul.hiddennav > li > a {
    display: list-item;
    line-height: 1em;
    padding: 2px 0px;
    text-decoration: none;
}
ul.sidenav > li > a:hover, ul.hiddennav > li > a:hover {
    color: #fed22f;
    text-decoration: underline;
}
/*--Drop down trigger styles--*/
ul.sidenav > li > span, ul.hiddennav > li > span {
    margin: 0px;
    padding: 2px 7px;
    float: right;
    font-weight: normal;
    font-family: Arial;
    font-size: 0.5em !important;
    line-height: 2em;
    text-decoration: none !important;
    color: #fff;
    position: absolute;
    top: 0px;
    right: 0px;
    border-radius: 5px;
    behavior: url(/modules/helper/PIE/PIE.htc);
}
ul.sidenav > li > span.subhover, ul.hiddennav > li > span.subhover {
    background-color: #333;
    cursor: pointer;
}
ul.sidenav > li > .context-menu, ul.hiddennav > li > .context-menu {
    right: 32px;
    top: -5px;
}
ul.sidenav > li > ul.subnav, ul.hiddennav > li > ul.subnav {
    position: absolute;
    float: left;
    display: none;
    left: 98.33%;
    top: 0;
    min-height: 35px;
    min-width: 205px;
    width: auto;
    margin: 0px 0px 5px 0px;
    padding: 0px;
    list-style: none;
    background-color: #333;
    border-radius: 0px 5px 5px 5px;
    z-index: 1;
    /* To make the subnav displays over the images-area */
}
ul.sidenav > li > ul.subnav li.sub-back, ul.hiddennav > li > ul.subnav li.sub-back {
    display: none;
}
ul.subnav > li > ul.subnav {
    display: none;
}
ul.subnav > div > div > li > ul.subnav {
    display: none;
}
ul.sidenav > li > ul.subnav > li, ul.hiddennav > li > ul.subnav > li {
    border-top: 0 !important;
    min-width: 190px;
    min-height: 15px;
    width: auto;
    padding: 0px 5px 0px 10px;
    margin: 3px;
    background-color: #333;
    border-radius: 5px;
    display: list-item;
    text-align: left;
    z-index: 0;
    white-space: nowrap;
    behavior: url(/modules/helper/PIE/PIE.htc);
}
ul.sidenav > li > ul.subnav > li:hover, ul.hiddennav > li > ul.subnav > li:hover {
    background-color: #444;
    box-shadow: none;
}
ul.sidenav > li > ul.subnav > li.hidden, ul.hiddennav > li > ul.subnav > li.hidden {
    display: none;
}
ul.sidenav > li > ul.subnav > li:hover > a, ul.hiddennav > li > ul.subnav > li:hover > a {
      color: #fed22f;
        text-decoration: underline;
}
ul.sidenav > li > ul.subnav > li > .context-menu, ul.hiddennav > li > ul.subnav > li > .context-menu {
      right: 5px;
        top: 0px;
}
ul.subnav > li > ul.preload-subnav {
      display: none;
}
ul.subnav > div > div > li > ul.preload-subnav {
      display: none;
}

    #content .hidable-container {
                  float: right;
                  text-align: left;
                  width: 78.12%;
                  padding: 0px;
                  margin: 0px 1% 10px;
              }
              #content .hidable {
                  margin: 10px 0px;
                  min-height: 30px;
                  clear: both;
              }
              #content > .title {
                margin: 0px;
                padding: 10px 1.04%;
                width: 78.12%;
                line-height: 1em;
            }
            #content .search-result .title {
                padding: initial;
                float: none;
            }
            #content .content-tag-title {
                margin: 0px;
                padding: 0px 1.04%;
                width: 78.12%;
                float: right;
            }
            .content-tag-title a.content-tag-title-link {
                color: #000;
                text-decoration: none;
            }
            #content .breadcrumb {
                float: left;
                font-size: 14px;
                margin: 0px;
                padding: 10px 1.04%;
                width: 78.12%;
            }
            #content .breadcrumb a {
                text-decoration: none
            }
            #midbar {
                float: left;
                width: 78.21%;
                position: relative;
            }
            ul.midnav {
                float: left;
                list-style: none;
                width: 100%;
                min-height: 20px;
                margin: 0.67%;
                border-style: dotted;
                border-width: 1px;
                border-radius: 5px;
                padding: 0;
            }
            ul.midnav > li {
                float: left;
                display: list-item;
                margin: 3px;
                padding: 0px 2% 0px 2%;
                height: auto;
                min-height: 30px;
                width: 27.6%;
                max-width: 325px;
                position: relative;
                border-radius: 5px;
            }
            ul.midnav>li>a {
                line-height: 1em;
                padding: 5px 0px;
                text-decoration: none;
                display: list-item;
            }
            ul.midnav > li > ul.preload-subnav {
                display: none;
            }
            #body-bg {
        background-color: #ffffff;
        padding: 0px 0px 40px 0px;
    }
    #wrapper {
        max-width: fullpx;
    }
    
			#content .breadcrumb,
			#content h1,
			#content .hidable-container,
			#content .album-images,
			#content .wrap-cart,
			#content > .title,
			#content .content-tag-title ,
			.checkout-step .progress-bar {
				width: 97.92%;
			}

			#content #midbar {
				width: 97.92%;
			}
			#content .webboard,
			#content .webboard-topic {
				width: 97.92%;
			}

			#content-tag-container {
				width: 97.92%;
			}
			.contact-us-wrap {
				width: 97.92%;
			}
		
		#header #topbar {
			background-color: #ffffff;
		}

		#header #topbar ul.topnav > li:not(.nav-add-button){
			background-color: #ffffff;
		}

		ul.topnav > li > a {
			color: #3b3b3b;
		}

		ul.topnav > li > span {
		  color: #3b3b3b;
		}

		.mobile-topbar{
		  color: #3b3b3b;
		  background-color: #ffffff;
		}

		.mobile-topbar .header-viewcart-box {
	        color: #3b3b3b;
	        background-color: #ffffff;
	    }

	    .mobile-topbar .header-viewcart-box i {
	        color: #3b3b3b;
	    }
	.ready-template-panel {
                background-color: #ffffff;
           }
           #content .title {
			    color: #2f4f9e;
            }
            #content .content-tag-title {
                color: #3b3b3b;
            }
            #content .content-tag-title .content-tag-title-link {
                color: #232e2d;
            }
            #content .breadcrumb {
                color: #63acff;
            }
            #content .breadcrumb a {
                color: inherit;
            }
			#content #midbar ul.midnav {
				border-color: #63acff;
			}
            #content #midbar ul.midnav > li > a {
                color: #63acff;
            }
            
		#content #sidebar {
		  background-color: #ffffff;
		}
		ul.sidenav > li {
		  background-color: #ffffff;
		}
		ul.sidenav > li > a {
		  color: #202020;
		}
		#content #sidebar .widgets ul.sidenav > li .arrow {
		  color: #202020;
		}
		#content #sidebar .viewcart-box {
		  background-color: #ffffff;
		  color: #232e2d;
		}
		#content #sidebar .viewcart-box a {
		  color: #232e2d;
		}
		#content .widget-item a {
		  color: #63acff;
		}
		#content .widget-item h3 {
		  color: #232e2d;
		}
		#content .widget-item div {
		  color: #3b3b3b;
		}
		#content .widget-item input[type=button],
		#content .widget-item input[type=submit] {
		  color: #ffffff;
		  background-color: #63acff;
		}
	</style>
<style>@font-face {
                 font-family: 'db-adman-x';
                 font-weight: normal;
                 font-style:  normal;
                 font-display: swap;
                 src: url('/modules/flexi/fonts/db-adman-x-webfont.ttf'); /* IE9 Compat Modes */
                 src: local('db-adman-x'),
                 url('/modules/flexi/fonts/db-adman-x-webfont.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
                 url('/modules/flexi/fonts/db-adman-x-webfont.woff') format('woff'), /* Modern browsers */
                 url('/modules/flexi/fonts/db-adman-x-webfont.ttf') format('truetype'); /* Safari, Android, iOS */
                 }@font-face {
                 font-family: 'db-adman-x-bd';
                 font-weight: normal;
                 font-style:  normal;
                 font-display: swap;
                 src: url('/modules/flexi/fonts/db-adman-x-bd-webfont.ttf'); /* IE9 Compat Modes */
                 src: local('db-adman-x-bd'),
                 url('/modules/flexi/fonts/db-adman-x-bd-webfont.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
                 url('/modules/flexi/fonts/db-adman-x-bd-webfont.woff') format('woff'), /* Modern browsers */
                 url('/modules/flexi/fonts/db-adman-x-bd-webfont.ttf') format('truetype'); /* Safari, Android, iOS */
                 }</style>    <link rel="preload" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.min.css" as="style" onload="this.rel='stylesheet'"/>
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.min.css"></noscript>
    <link rel="preload" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.structure.min.css" as="style" onload="this.rel='stylesheet'"/>
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.structure.min.css"></noscript>
    <link rel="preload" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.theme.min.css" as="style" onload="this.rel='stylesheet'"/>
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery-ui/css/jquery-ui-1.11.0.stable.theme.min.css"></noscript>
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/js/jquery.colorbox/colorbox.min.css"   />
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.colorbox/colorbox.min.css"></noscript>
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/js/jquery.qtip/jquery.qtip-2.2.0.min.css"  />
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.qtip/jquery.qtip-2.2.0.min.css"></noscript>
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/js/jquery.mCustomScrollbar/css/jquery.mCustomScrollbar.css"  />
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.mCustomScrollbar/css/jquery.mCustomScrollbar.css"></noscript>
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/font-awesome-4.7.0/css/font-awesome.min.css" />
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/fontello/css/fontello.css" />
    <noscript><link rel="stylesheet" href="/modules/flexi/css/font-awesome-4.7.0/css/font-awesome.min.css"></noscript>
    <noscript><link rel="stylesheet" href="/modules/flexi/css/fontello/css/fontello.css"></noscript>
    <link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" href="/modules/flexi/js/jquery.simplePagination/simplePagination.css" /> 
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.simplePagination/simplePagination.css"></noscript>
    <link rel="preload" href="/modules/flexi/js/jquery.dropdown/jquery.dropdown.min.css" as="style" onload="this.rel='stylesheet'" />
    <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.dropdown/jquery.dropdown.min.css"></noscript>

            <link rel="preload" href="/modules/flexi/js/jquery.tosrus/css/jquery.tosrus.all.css" as="style" onload="this.rel='stylesheet'" />
        <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.tosrus/css/jquery.tosrus.all.css"></noscript>
    
        <link rel="preload" href="/modules/flexi/css/flag-icon-css/css/flag-icon.min.css" as="style" onload="this.rel='stylesheet'" />
        <noscript><link rel="stylesheet" href="/modules/flexi/css/flag-icon-css/css/flag-icon.min.css"></noscript>
    
        <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/js/jquery.lightbox2/dist/css/lightbox.min.css?v=4.37.0" />
        <noscript><link rel="stylesheet" href="/modules/flexi/js/jquery.lightbox2/dist/css/lightbox.min.css?v=4.37.0"></noscript>
    
<!--[if lt IE 7 ]> <link rel="stylesheet" type="text/css" href="/modules/flexi/js/tinymce_4/skins/lightgray/skin.ie7.min.css" /> <![endif]-->
    <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/always.css?v=4.37.0" />
    <noscript><link rel="stylesheet" href="/modules/flexi/css/always.css?v=4.37.0"></noscript>
<style>table { border-collapse: collapse; border-spacing: 0px; }
#content .price-box { float: left; } #content .price-box td { width: 1px; white-space: nowrap; }
#content .price-box .price-value { text-align: right; }
#content .price-box .price-container { position: relative; }
#content .price-box td span { white-space: nowrap; }
button, input, select, textarea { font-family: inherit; font-size: 100%; }
button, input { line-height: normal; }
#content .order-button-box { float: right; }
#content .hidable .order-button { float: right; margin: 5px 0px; padding: 0px; text-align: left; }
#content .hidable .order-button input[type="text"] { width: 50px; }
#content .hidable .order-button span#btn_order_div { display: inline-block; }
button, html input[type="button"], input[type="reset"], input[type="submit"] { -webkit-appearance: button; cursor: pointer; }
#content .hidable .order-button input#btn_order, #content .hidable .order-button input[type="button"], #content .hidable .order-button input[type="submit"] { min-width: 200px; padding: 10px 15px; border-radius: 5px; border: none; cursor: pointer; }
#content .order-button input#btn_order { overflow: visible; }
#content .price-line {
	font-size: 20px;
	margin: 5px 0px;
	/*display: block;*/
	> .price {
		min-width: 10px;
	}
}
#content .price-line-space {
	float: left;
	width: 30px;
}
#content .original-price-line {
	font-size: 20px;
	margin: 5px 0px;
	/*display: block;*/
	> .price {
		min-width: 10px;
	}
}
#content .member-price-line {
	font-size: 20px;
	margin: 5px 0px;
	/*display: block;*/
	> .price {
		min-width: 10px;
	}
}#content .social-buttons { margin: 5px 0px; padding: 0px; text-align: left; }
#content .social-buttons .left { float: left; }
.fb_iframe_widget { display: inline-block; position: relative; }
.fb_iframe_widget span { display: inline-block; position: relative; text-align: justify; }
.fb_iframe_widget iframe { position: absolute; }
#content .social-buttons .right { float: right; } #content .social-buttons .social-button-item {
  float: left;
  margin: 0 5px;
}#showcase-container {
  margin: 5px 0px;
  text-align: left;
}
#showcase-container ul, #showcase-container ol {
  list-style: none;
}
#showcase-container .portlet-children.larger-image .subpages .image, #showcase-container .portlet-parent.larger-image .subpages .image {
  width: 25%;
  max-width: 100% !important;
  height: auto !important;
  margin: 10px 3% 5px 1% !important;
}
#showcase-container .portlet-children.larger-image .subpages .image img, #showcase-container .portlet-parent.larger-image .subpages .image img {
  max-width: 100% !important;
  max-height: 200px !important;
}
#showcase-container .portlet-children.larger-image .subpages .image .fa-stack, #showcase-container .portlet-parent.larger-image .subpages .image .fa-stack {
  top: 25% !important;
  font-size: 1.5em !important;
}
#showcase-container .showcase.full .portlet-children.larger-image.no-desc .subpages > li {
  width: 225px !important;
}
#showcase-container .showcase.full .portlet-children.larger-image.no-desc .subpages .image {
  width: 217px !important;
  max-width: 100% !important;
  height: 127px !important;
  line-height: 121px !important;
  margin: 10px auto 5px !important;
  position: relative;
}
#showcase-container .showcase.full .portlet-children.larger-image.no-desc .subpages img {
  width: auto !important;
  max-height: 100% !important;
}
#showcase-container .showcase.half .portlet-children.larger-image .subpages .image, #showcase-container .showcase.half .portlet-parent.larger-image .subpages .image {
  width: 45% !important;
  margin: 10px 5% 5px 1% !important;
}
#showcase-container .showcase.half .portlet-children.larger-image.no-desc .subpages > li, #showcase-container .showcase.half .portlet-parent.larger-image.no-desc .subpages > li {
  width: 217px !important;
}
#showcase-container .showcase.half .portlet-children.larger-image.no-desc .subpages .image, #showcase-container .showcase.half .portlet-parent.larger-image.no-desc .subpages .image {
  width: 197px !important;
  height: 115px !important;
  line-height: 111px !important;
  margin: 10px auto 1% !important;
}
#showcase-container .showcase.half .portlet-children.larger-image.no-desc .subpages img, #showcase-container .showcase.half .portlet-parent.larger-image.no-desc .subpages img {
  width: auto !important;
  max-height: 100% !important;
}
.showcase.full {
  width: 100%;
}
.showcase.full > li.placeholder {
  width: 100% !important;
}
.showcase.half {
  width: 48%;
}
.showcase.half > li.placeholder {
  width: 100% !important;
}
.showcase.left {
  float: left;
}
.showcase.right {
  float: right;
}
.showcase .portlet-header {
  min-height: 18px;
  padding: 6px 20px;
  font-family: RSU;
  font-size: 20px;
  line-height: 1em;
  text-align: left;
  color: #fff;
  background-color: #000;
  border: 1px solid #000;
  border-radius: 5px 5px 0px 0px;
}
.showcase .portlet-header > a {
  color: #fff;
  text-decoration: none;
}
.showcase .portlet-header > a:hover {
  color: #fed22f;
  text-decoration: underline;
}
.showcase .portlet {
  border: solid 1px #000;
  border-radius: 7px;
  margin: 5px 0px;
}
.showcase .portlet > ul {
  margin: 0px 5px;
}
.showcase .portlet .separator {
  border-top: dotted 1px #ccc;
  border-bottom: none;
  margin-left: auto;
  margin-right: auto;
}
.showcase .portlet .subpages > li {
  margin: 0;
  padding: 0;
  border: 0;
}
.showcase .portlet.style1 .showcase_border {
  border: none;
}
.showcase .portlet.style1 .portlet-header-divider {
  display: none;
}
.showcase .portlet.style1 .portlet-header-divider > div {
  display: none;
}
.showcase .portlet.style2 {
  border: none;
}
.showcase .portlet.style2 .portlet-header {
  border: none;
  background: none;
}
.showcase .portlet.style2 .portlet-header > a {
  color: #000;
}
.showcase .portlet.style2 .portlet-header > a:hover {
  color: #000;
}
.showcase .portlet.style2 .showcase_border {
  border: 1px solid #000;
  border-radius: 10px;
}
.showcase .portlet.style2 .portlet-header-divider {
  display: none;
}
.showcase .portlet.style2 .portlet-header-divider > div {
  display: none;
}
.showcase .portlet.style3 {
  border: none;
}
.showcase .portlet.style3 .portlet-header {
  border: none;
  background: none;
}
.showcase .portlet.style3 .portlet-header > a {
  color: #000;
}
.showcase .portlet.style3 .portlet-header > a:hover {
  color: #000;
}
.showcase .portlet.style3 .showcase_border {
  border: none;
}
.showcase .portlet.style3 .portlet-header-divider {
  display: block;
  padding: 0px 2.67%;
}
.showcase .portlet.style3 .portlet-header-divider > div {
  border-bottom: solid 1px black;
}
.showcase .portlet-parent {
  margin: 20px 2.67%;
}
.showcase .portlet-children {
  margin: 10px 1.33%;
}
.showcase .portlet-children > .subpages > li {
  display: inline-block;
  /* START: inline-block IE7 hack */
  *display: inline;
  *zoom: 1;
  /* END: inline-block IE7 hack */
  margin: 0;
  padding: 0;
  text-align: center;
  vertical-align: top;
}
.showcase .portlet-children > .subpages > li > .text > .price {
  float: none;
  margin-top: 5px;
}
.showcase > .portlet.layout2 .portlet-children > .subpages > li {
  display: block;
  width: auto;
  text-align: left;
}
.showcase > .portlet.layout1 .portlet-children > .subpages > li > .text {
  overflow: visible;
  /* to make the description visible */
  margin: 5px 3%;
}
.portlet-children.no-desc .subpages .image {
  width: 141px;
  height: 82px;
  line-height: 82px;
  margin: 10px auto 5px;
  float: none;
  text-align: center;
}
.subpages .image, .search-result .image {
  font-size: 20px;
}
.showcase.full .portlet-children > .subpages > li {
  width: 25%;
  min-width: 180px;
  margin-right: 1.67%;
}
.showcase.half .portlet-children > .subpages > li {
  width: 50%;
  min-width: 170px;
}
.showcase.full .portlet-children.no-desc > .subpages > li {
  margin-left: 0;
  margin-right: 0;
  width: 25%;
  min-width: 180px;
}
.showcase.half .portlet-children.no-desc > .subpages > li {
  margin-left: 0;
  margin-right: 0;
  width: 50%;
  min-width: 170px;
}

#content .contact-form {
  margin: 5px 0px;
  padding: 0px;
  text-align: left;
}
#content .contact-form ul {
  list-style: none;
}
#content .contact-form label {
  text-align: left;
  display: inline-block;
  width: 150px;
}
#content .contact-form input[type=text] {
  border-radius: 4px 4px 4px 4px;
  border: 1px solid #bbb;
  height: 25px;
  width: 69.55%;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#content .contact-form textarea {
  border-radius: 4px 4px 4px 4px;
  border: 1px solid #bbb;
  height: 25px;
  width: 69.55%;
  height: 70px;
  resize: none;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#content .contact-form select {
  border-radius: 4px 4px 4px 4px;
  border: 1px solid #bbb;
  height: 25px;
  width: 250px;
}
#content .contact-form input[type=button], #content .contact-form input[type=submit] {
  padding: 10px 15px;
  min-width: 300px;
  width: 80%;
  border-radius: 5px;
  border: none;
  cursor: pointer;
}
#content .contact-form .warning {
  margin: 1em auto;
  font-style: italic;
}
#content .contact-form .form-icon {
  position: absolute;
  top: 10px;
  right: 13%;
  opacity: 0.6;
  width: 1em;
  text-align: center;
}
#content .contact-form #security_code {
  padding-right: 0;
  width: 362px;
}
#content .contact-form .error {
  color: red;
}
#content .contact-form .contact-block {
  margin: 5px auto;
  width: 520px;
}
#content .contact-form .contact-block-hidden {
  display: none;
}
#content .contact-form .button {
  text-align: left;
}
#content .contact-form .contact-block img {
  vertical-align: middle;
  margin-right: 20px;
}
#content .contact-form .right {
  float: right;
  margin-right: 100px;
}
#content .contact-form .left {
  float: left;
}
#content .contact-form .formErrorAlert {
  color: #fee;
  display: block;
  font-weight: bold;
  position: absolute;
  margin: -50px 0 0 200px;
}
#content .contact-form .formError {
  background: none repeat scroll 0 0 #fee;
  border: 2px solid #f00;
  border-radius: 6px 6px 6px 6px;
  box-shadow: 0 0 6px #000;
  color: #f00;
  font-family: tahoma;
  font-size: 11px;
  padding: 4px 10px;
  text-align: center;
  position: relative;
  /*width: 150px;*/
}
#content .contact-form .formErrorArrow div {
  background: none repeat scroll 0 0 #fee;
  border-left: 2px solid #f00;
  border-right: 2px solid #f00;
  box-shadow: 0 2px 3px #444;
  display: block;
  font-size: 0;
  height: 1px;
  line-height: 0;
  margin: 0 auto;
}
#content .contact-form .button {
  width: 220px;
  clear: both;
  color: #fff;
  font-family: Tahoma, Arial, Helvetica, sans-serif;
  font-size: 14px;
  margin: auto;
  padding: 0;
  text-align: center;
}
#content .contact-form .button > a {
  background-color: #000;
  background-position: 5px center;
  background-repeat: no-repeat;
  border-radius: 3px 3px 3px 3px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.7);
  color: #fff;
  display: block;
  font-size: 1em;
  margin: 5px;
  padding: 10px 10px 10px 30px;
  text-decoration: none;
  cursor: pointer;
}
#content .contact-form #btn-add-form > a {
  background-image: url("/modules/flexi/images/add-button.png");
}
#content .contact-form #btn-edit-form > a {
  background-image: url("/modules/flexi/images/select-white.png");
  background-position: 10px 10px;
}
#content .contact-form .button > a:hover {
  color: #fed22f;
  background-color: #333;
}
#content .contact-form .reCaptcha-container {
  width: 80%;
  margin: auto;
  overflow: hidden;
}
#content .contact-form .reCaptcha-container > div {
  transform: scale(0.9);
  -webkit-transform: scale(0.9);
  transform-origin: 0 0;
  -webkit-transform-origin: 0 0;
}
.formErrorArrow {
  width: 17px;
  margin: -2px 0 0 13px;
  position: relative;
}
.formErrorArrow .line9 {
  width: 15px;
}
.formErrorArrow .line8 {
  width: 13px;
}
.formErrorArrow .line7 {
  width: 11px;
}
.formErrorArrow .line6 {
  width: 9px;
}
.formErrorArrow .line5 {
  width: 7px;
}
.formErrorArrow .line4 {
  width: 5px;
}
.formErrorArrow .line3 {
  width: 3px;
}
.formErrorArrow .line2 {
  width: 1px;
}
.formErrorArrow .line1 {
  width: 0px;
}
#contact-form-status {
  text-align: center;
  font-weight: bold;
  font-size: 13px;
  color: #2fa41e;
  padding: 20px 5px;
}
#contact-form-status.error {
  color: red;
}
.contact-form-selector {
  min-width: 560px;
  padding: 10px;
}
.contact-form-selector h2 {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #fff;
  background-color: #494949;
  padding: 5px;
  margin: 5px 5px 15px 5px;
  border-radius: 5px 5px 5px 5px;
}
.contact-form-selector fieldset {
  border: solid 1px #aaa;
  border-radius: 5px;
  padding: 5px;
  margin-bottom: 10px;
}
.contact-form-selector ul {
  margin: 0px auto;
}
.contact-form-selector .item {
  float: left;
  min-width: 170px;
  padding: 10px;
  margin: 5px;
  text-align: center;
  border-radius: 5px 5px 5px 5px;
  color: #fff;
  background-color: #000;
  cursor: pointer;
}
.contact-form-selector .item:hover {
  color: #000;
  background-color: #ffe45c;
}
.contact-form-selector .item.disabled, .contact-form-selector .item.disabled:hover {
  color: #888;
  background-color: #ccc;
  cursor: default;
}
.contact-form-selector .item > a {
  text-decoration: none;
}
/*--Standard Form--*/
#content .contact-form .standard-form {
  margin: 5px auto;
  width: 57.29%;
}
#content .contact-form .standard-form h3 {
  text-align: center;
  margin: 5px 0;
}
#content .contact-form .standard-form ul * {
  vertical-align: top;
}
#content .contact-form .standard-form ul li {
  min-height: 30px;
  padding: 5px 0.01%;
  position: relative;
}
#content .contact-form .standard-form ul li label {
  width: 18.82%;
  text-align: right;
}
#content .contact-form .standard-form #widget #email {
  background-image: url("");
}
#content .contact-form .standard-form .warning {
  margin: 1em auto;
  font-style: italic;
}
#content .contact-form .standard-form .captcha {
  width: 80%;
  margin: auto;
}
#content .contact-form .standard-form .captcha .image {
  max-width: 80%;
  padding: 20px 0px;
  vertical-align: middle !important;
}
#content .contact-form .standard-form .captcha .reload {
  width: 8%;
  vertical-align: middle !important;
}
/*--Customize Form--*/
#content .contact-form .customize-form {
  margin: 5px auto;
  width: 57.29%;
}
#content .contact-form .customize-form h3 {
  text-align: center;
  margin: 5px 0;
}
#content .contact-form .customize-form .description {
  text-align: center;
  margin: 5px 0;
}
#content .contact-form .customize-form ul * {
  vertical-align: top;
}
#content .contact-form .customize-form ul li {
  min-height: 30px;
  padding: 2px;
  position: relative;
}
#content .contact-form .customize-form ul li i.fa-envelope {
  color: #ccc;
  position: absolute;
  right: 13%;
  top: 8px;
  opacity: 0.6;
}
#content .contact-form .customize-form ul li .file-container {
  display: block;
  vertical-align: bottom;
  width: 70%;
  position: relative;
  top: -15px;
  left: 110px;
}
#content .contact-form .customize-form ul li .file-container .file-list span {
  display: block;
  width: 70%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
#content .contact-form .customize-form ul li .file-container .file-list a {
  display: block;
  width: 60px;
  text-align: center;
  position: absolute;
  top: 0;
  right: 5%;
}
#content .contact-form .customize-form ul li .file-container a {
  margin-left: 5px;
  padding: 5px;
  *padding: 10px;
  /*IE 7*/
  border-radius: 5px;
}
#content .contact-form .customize-form ul li .file-container i {
  margin-top: 3px;
  right: 0px;
  top: 0px;
}
#content .contact-form .customize-form ul li label {
  width: 18.82%;
  text-align: right;
  padding-top: 5px;
}
#content .contact-form .customize-form form input[type=button], #content .contact-form .customize-form form input[type=submit] {
  cursor: pointer;
  padding: 10px 15px;
  min-width: 300px;
  width: 80%;
  border-radius: 5px;
  border: none;
}
#content .contact-form .customize-form .warning {
  padding: 0.5em;
  font-style: normal;
  font-size: 1.5em;
  color: white;
  background-color: red;
}
#content .contact-form .customize-form .captcha {
  width: 80%;
  margin: 10px auto;
}
#content .contact-form .customize-form .captcha .image {
  max-width: 80%;
  padding: 20px 0px;
  vertical-align: middle !important;
}
#content .contact-form .customize-form .captcha .reload {
  width: 8%;
  vertical-align: middle !important;
}
.contact-form-selector .form-list {
  font-size: 12px;
  max-height: 250px;
  overflow: auto;
}
.contact-form-selector .form-list table {
  width: 100%;
  background-color: #fff;
}
.contact-form-selector .form-list tr.odd {
  background-color: #eee;
}
.contact-form-selector .form-list th {
  background-color: #000;
  color: #fff;
  text-align: center;
  border: 1px solid #fff;
  font-weight: bold;
  padding: 2px;
}
.contact-form-selector .form-list td {
  padding: 0 5px;
  border: 1px solid #fff;
}
.contact-form-selector .form-list td.left {
  text-align: left;
}
.contact-form-selector .form-list td.right {
  text-align: right;
}
.contact-form-selector .form-list td.center {
  text-align: center;
}
.contact-form-selector .form-list td.date {
  width: 100px;
  text-align: center;
}
.contact-form-selector .form-list td a {
  text-decoration: none;
}
.contact-form-selector .form-list td a:hover {
  cursor: pointer;
}
.contact-form-selector .form-list td a > span {
  background-color: #000;
  border-radius: 3px;
  color: #fff;
  padding: 2px 4px;
}
.contact-form-selector .form-list td a > span:hover {
  color: #ffe45c;
}

/*--Widget Form Standard--*/
#sidebar .widget-item .standard-form {
  margin: 5px auto;
  width: 100%;
  font-size: 14px;
  font-weight: normal;
}
#sidebar .widget-item .standard-form h3 {
  font-size: 18px;
  margin: 5px 0;
  text-align: center;
}
#sidebar .widget-item .standard-form .description {
  text-align: center;
  margin: 5px 0;
}
#sidebar .widget-item .standard-form ul * {
  vertical-align: top;
  width: 97%;
}
#sidebar .widget-item .standard-form ul li {
  min-height: 30px;
  padding: 5px 2.77%;
  list-style-type: none;
  text-align: left;
  position: relative;
}
#sidebar .widget-item .standard-form ul li i {
  width: 15px;
}
#sidebar .widget-item .standard-form ul li label {
  width: 120px;
  font-size: 14px;
  font-weight: normal;
}
#sidebar .widget-item .standard-form form input[type=text], #sidebar .widget-item .standard-form form textarea {
  border: solid 1px #bbb;
  border-radius: 4px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#sidebar .widget-item .standard-form form input[type=text] {
  height: 27px;
}
#sidebar .widget-item .standard-form form textarea {
  resize: none;
}
#sidebar .widget-item .standard-form form input[type=button], #sidebar .widget-item .standard-form form input[type=submit] {
  cursor: pointer;
  width: 100%;
  padding: 5px 10px;
  border-radius: 5px;
  border: none;
}
#sidebar .widget-item .standard-form .warning {
  margin: 1em auto;
  font-style: italic;
}
#sidebar .widget-item .standard-form .contact-block-hidden {
  display: none;
}
#sidebar .widget-item .standard-form .captcha {
  max-width: 100%;
  margin: 10px auto;
}
#sidebar .widget-item .standard-form .captcha .image {
  max-width: 80%;
  padding: 20px 0px;
  vertical-align: middle !important;
}
#sidebar .widget-item .standard-form .captcha .reload {
  width: 10%;
  vertical-align: middle !important;
}
/*--Widget Form Customize--*/
#sidebar .widget-item .customize-form {
  /*font-family: Tahoma,Arial,Helvetica,sans-serif;*/
  margin: 5px auto;
  width: 100%;
  font-size: 14px;
  font-weight: normal;
}
#sidebar .widget-item .customize-form h3 {
  font-size: 18px;
  margin: 5px 0;
  text-align: center;
}
#sidebar .widget-item .customize-form .description {
  text-align: center;
  margin: 5px 0;
}
#sidebar .widget-item .customize-form ul li {
  min-height: 30px;
  padding: 5px;
  list-style-type: none;
  text-align: left;
  position: relative;
  width: 97%;
}
#sidebar .widget-item .customize-form ul li input[class="field-input"], #sidebar .widget-item .customize-form ul li input[class="field-email"], #sidebar .widget-item .customize-form ul li textarea[class="field-textarea"] {
  width: 97%;
}
#sidebar .widget-item .customize-form ul li input[type=text], #sidebar .widget-item .customize-form ul li textarea {
  border: solid 1px #bbb;
  border-radius: 4px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#sidebar .widget-item .customize-form ul li input[type=text] {
  height: 27px;
}
#sidebar .widget-item .customize-form ul li textarea {
  resize: none;
}
#sidebar .widget-item .customize-form ul li .file-container {
  display: block;
  padding: 5px 0 20px 0;
  width: 97%;
  margin-top: 5px;
}
#sidebar .widget-item .customize-form ul li .file-container .file-list {
  width: 97%;
}
#sidebar .widget-item .customize-form ul li .file-container .file-list span {
  width: 60%;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: 0;
}
#sidebar .widget-item .customize-form ul li .file-container .file-list a.remove-file {
  padding: 7px 5px 5px;
  border-radius: 5px;
  position: absolute;
  top: 0;
  right: 0;
  text-align: center;
  width: 30px;
}
#sidebar .widget-item .customize-form ul li .file-container a {
  padding: 7px 5px 5px;
  border-radius: 5px;
}
#sidebar .widget-item .customize-form ul li label, #sidebar .widget-item .customize-form ul li a {
  font-size: 14px;
  font-weight: normal;
  width: 66.67%;
}
#sidebar .widget-item .customize-form ul li i.fa-envelope {
  display: block;
  color: #ccc;
  position: absolute;
  font-size: 18px;
  width: 18px;
  /*top: 30.5px;*/
  bottom: 10px;
  right: 10%;
  opacity: 0.6;
}
#sidebar .widget-item .customize-form form input[class="field-input"], #sidebar .widget-item .customize-form form input[class="field-email"], #sidebar .widget-item .customize-form form textarea[class="field-textarea"] {
  border: 1px solid #bbb;
  border-radius: 4px 4px 4px 4px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#sidebar .widget-item .customize-form form input[class="field-input"], #sidebar .widget-item .customize-form form input[class="field-email"] {
  height: 27px;
}
#sidebar .widget-item .customize-form form input[type=button], #sidebar .widget-item .customize-form form input[type=submit] {
  cursor: pointer;
  width: 100%;
  padding: 5px 10px;
  border-radius: 5px;
  border: none;
}
#sidebar .widget-item .customize-form form textarea[class="field-textarea"] {
  resize: none;
}
#sidebar .widget-item .customize-form .warning {
  margin: 1em auto;
  font-style: italic;
}
#sidebar .widget-item .customize-form .contact-block-hidden {
  display: none;
}
#sidebar .widget-item .customize-form .captcha {
  max-width: 100%;
  margin: 10px auto;
}
#sidebar .widget-item .customize-form .captcha .image {
  max-width: 80%;
  padding: 20px 0px;
}
#sidebar .widget-item .customize-form .captcha .reload {
  width: 10%;
}
.contact-us-wrap {
  width: 78.12%;
  margin: 0px auto;
  overflow: hidden;
  padding-bottom: 10px;
}
.contact-us-wrap .order-complete {
  border: 1px solid #ccc;
  border-radius: 10px 10px 10px 10px;
  padding: 50px;
  text-align: center;
  margin-top: 20px;
}
.contact-us-wrap .back-home {
  font-size: 13px;
  padding-top: 20px;
}
.subpages {
  list-style: none;
}
.subpages .separator {
  border-top: dotted 1px #ccc;
  border-bottom: none;
  margin-left: auto;
  margin-right: auto;
}
.subpages > li {
  color: #000;
  font-size: 13px;
  padding: 10px 2.66%;
  margin: 10px 0px;
  border: none !important;
}
.subpages > li.no-children {
  text-align: center;
  font-size: 1em;
  font-style: italic;
  color: #ccc;
}
.subpages .text {
  overflow: hidden;
  /* to make the price aligned with the description */
  padding-top: 10px;
}
.subpages .text .title, .subpages .text .title a {
  font-size: 20px;
  font-weight: bold;
  /*line-height: 20px;*/
}
.subpages .text .description {
  font-size: 14px;
  font-weight: normal;
}
.subpages .text a {
  color: #000;
  text-decoration: none;
}
.subpages .text a:hover {
  text-decoration: underline !important;
}
.subpages .text .price {
  margin-top: 10px;
  font-size: 20px;
  font-weight: normal;
}
.subpages .text .order-button {
  float: right;
  margin-top: 10px;
}
.subpages .showcase-price-box {
  width: 100%;
}
.subpages .showcase-price-box td {
  width: 1px;
  white-space: nowrap;
}
.subpages .showcase-price-box td > span {
  width: 1px;
  white-space: nowrap;
}
.subpages .showcase-price-box .price-label {
  text-align: left;
}
.subpages .showcase-price-box .price-value {
  text-align: right;
}
.subpages .image {
	position: relative;
    float: left;
    width: 141px;
    height: 82px;
    margin: 10px 5% 5px 1%;
    text-align: center;
    line-height: 82px;
    font-size: 20px;
}

.subpages .image > a > img {
	margin: auto;
	max-width: 100%;
	max-height: 100%;
	position: relative;
	vertical-align: middle;
}
.comment_container {
  position: relative;
}
.comment_container, .comment_form {
  border: 1px solid #ccc;
  padding: 10px;
  background-color: transparent;
  margin: 10px 0px;
  font-weight: normal;
  border-radius: 5px;
}
.comment_container .reCaptcha-container, .comment_form .reCaptcha-container {
  overflow: hidden;
  float: left;
}
.comment_container .reCaptcha-container > div, .comment_form .reCaptcha-container > div {
  transform: scale(0.9);
  -webkit-transform: scale(0.9);
  transform-origin: 0 0;
  -webkit-transform-origin: 0 0;
}
.comment_form .hidden-on-load {
  display: none;
  padding: 0 0 10px 0;
}
.comment_form textarea {
  width: 99%;
  height: 200px;
}
.comment_form textarea.narrow {
  height: 30px;
}
.comment_form input[type=text] {
  border: 1px solid #bbb;
  border-radius: 4px;
  height: 25px;
  line-height: 25px;
  width: 40%;
  margin-top: 10px;
  margin-bottom: 10px;
}
.comment_form textarea {
  margin: 10px 0px;
  border: 1px solid #bbb;
  border-radius: 5px;
}
.comment_container > .info {
  font-size: 12px;
  font-weight: normal;
  color: #000;
}
.comment_container > .info a {
  font-size: inherit;
  font-weight: inherit;
  color: inherit;
  text-decoration: none;
}
.comment_container > .info a:hover {
  text-decoration: underline;
}
.comment_container > .show-all {
  text-align: center;
}
.comment_container > .comment_description {
  margin-top: 10px;
  font-weight: normal;
  color: #000;
}
.comment_container > .comment_description > img {
  vertical-align: bottom;
  float: right;
  max-height: 50px;
  max-width: 50px;
}
#comment-tabs {
  margin-top: 10px;
  background: transparent;
  border: none;
}

#facebook-comment{
    margin-left:0px !important;
}

.fb-comments, .fb-comments span, .fb-comments iframe {
        width: 100% !important;
}
#comment-tabs .ui-corner-top, #comment-tabs .ui-corner-left, #comment-tabs .ui-corner-all {
  -moz-border-radius-topleft: 4px;
  -moz-border-radius-topright: 4px;
  -webkit-border-top-left-radius: 4px;
  -webkit-border-top-right-radius: 4px;
  -khtml-border-top-left-radius: 4px;
  -khtml-border-top-right-radius: 4px;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}
#comment-tabs .ui-tabs-nav {
  border: none;
  border-bottom: solid 1px #212121;
  border-radius: 0px;
  background: transparent;
  color: #222;
  font-weight: bold;
}
#comment-tabs .ui-tabs-nav > li {
  background-image: none;
  /*width: 16.13%;*/
}
#comment-tabs .ui-tabs-nav > li.facebook i {
  color: #3b5998;
  margin-right: 10px;
  text-shadow: none;
  border-radius: 5px;
  background-color: white;
}
#comment-tabs .ui-tabs-nav > li > a {
  float: left;
  padding: 0.5em 1em;
  text-decoration: none;
  font-size: 20px;
}
#comment-tabs .ui-tabs-nav > li.facebook > a {
  padding-left: 10px;
}
#comment-tabs .ui-tabs-nav > li > a:hover {
  text-shadow: 0 1px 1px black;
}
#comment-tabs .ui-tabs-nav > li.ui-tabs-selected > a:hover {
  text-shadow: none;
}
#comment-tabs .ui-tabs-panel {
  padding: 10px;
}
.comment_delete > a {
  background-color: #000;
  background-image: url(/modules/flexi/images/trash-icon.png);
  background-position: 5px center;
  background-repeat: no-repeat;
  border-radius: 3px 3px 3px 3px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.698);
  color: #fff;
  display: block;
  font-size: 1em;
  font-weight: normal;
  margin: 0px;
  padding: 7px 10px;
  text-decoration: none;
  width: 15px;
  text-align: right;
}
.comment_delete > a:hover {
  color: #fff;
  background-color: #fed22f;
}
#validate_detail, #validate_username {
  color: red;
}
#comment .button_save {
  background-color: #ccc;
  border-radius: 5px;
  padding: 5px 15px;
  cursor: pointer;
}
.captcha .image {
  vertical-align: middle;
}
.captcha .reload {
  vertical-align: middle;
  cursor: pointer;
}
.comment-captcha-error {
  color: red;
}
.comment-member-info {
  float: right;
  padding: 0 10px 0 0;
}
.comment-member-info > img {
  vertical-align: bottom;
  max-height: 100px;
  max-width: 100px;
}
.comment-member-info > span {
  /*vertical-align: middle;*/
}
#comment .button_save {
  margin-top: 15px;
}.related-contents {
  list-style: none;
}

.related-contents .separator {
  border-top: dotted 1px #ccc;
  border-bottom: none;
  margin-left: auto;
  margin-right: auto;
}
.related-contents > li {
  color: #000;
  font-size: 13px;
  padding: 10px 0.67% 10px 4.67%;
  margin: 10px 0px;
  border: none !important;
}
.related-contents .image {
  float: left;
  position: relative;
  width: 100px;
  height: 59px;
  margin-right: 20px;
  margin-bottom: 20px;
  text-align: center;

}
.related-contents .image > a > img {
  margin: auto;
  max-width: 100%;
  max-height: 100%;
  vertical-align: middle;
}
.related-contents .image > a > img:hover {
  -webkit-filter: brightness(120%);
  filter: brightness(120%);
}
.related-contents .text .title, .related-contents .text .title a {
  font-size: 20px;
  font-weight: bold;
}
.related-contents .text a {
  color: #000;
  text-decoration: none;
}
.related-contents .text a:hover {
  text-decoration: underline !important;
}
.related-contents .text .showcase-price-box {
  width: 100%;
}
.related-contents .text .original-price {
  margin-top: 10px;
  font-size: 20px;
  font-weight: normal;
  vertical-align: top;
}
.related-contents .text .price {
  margin-top: 10px;
  font-size: 20px;
  font-weight: normal;
  vertical-align: top;
}
.related-contents .text .member-price {
  margin-top: 10px;
  font-size: 20px;
  font-weight: normal;
  vertical-align: top;
}
.related-contents .text .price-value {
  text-align: right;
}
#portlet-related-contents {
  font-family: RSU;
  font-size: 20px;
}
#portlet-related-contents .related-contents > li > .text {
  overflow: hidden;
}
#portlet-related-contents .related-contents > li {
  display: inline-block;
  /* START: inline-block IE7 hack */
  *display: inline;
  *zoom: 1;
  /* END: inline-block IE7 hack */
  text-align: left;
  vertical-align: top;
  width: 27.6%;
  min-width: 92px;
}
.related-contents .showcase-price-box td {
  width: 1px;
  white-space: nowrap;
}
.related-contents .showcase-price-box td > span {
  width: 1px;
  white-space: nowrap;
}
.related-contents .showcase-price-box .price-label {
  text-align: left;
}
.related-contents .showcase-price-box .price-value {
  text-align: right;
}
#slideshow-loader #slideshow-wrapper {
  z-index: 0;
  background-color: transparent;
  margin-left: auto;
  margin-right: auto;
  box-shadow: none;
}
#slideshow-loader .nivo-caption {
  filter: alpha(opacity=80) !important;
}
#slideshow-loader .nivo-caption > a {
  text-decoration: none !important;
  border-bottom: none !important;
}
#slideshow-loader .nivo-caption > a:hover {
  text-decoration: underline !important;
}
#slideshow-loader .nivo-controlNav {
  margin-top: -20px !important;
  margin-bottom: -20px !important;
}
#slideshow-loader .nivo-controlNav > a {
  /* START: text-indent IE7 hack */
  *text-indent: 0;
  *line-height: 0;
  /* END: text-indent IE7 hack */
}
#slideshow-loader .nivo-directionNav > a {
  /* START: text-indent IE7 hack */
  *text-indent: 0;
  *line-height: 0;
  /* END: text-indent IE7 hack */
}.text-section-container .text-section-loader {
  max-width: 100%;
}
.text-section-container .text-section-loader.narrow {
  max-width: 960px;
  margin: auto;
}
.text-section-container .text-section-loader img, .text-section-container .text-section-loader table, .text-section-container .text-section-loader iframe, .text-section-container .text-section-loader embed, .text-section-container .text-section-loader object {
  max-width: 100%;
}
#content .text-section-container .text-section-loader {
  min-height: 30px;
  width: 100%;
}
#content .text-section-container .text-section-loader > p {
  margin-top: 0px;
  margin-bottom: 10px;
}
#content .text-section-container .text-section-loader.text-section-loader ul {
  list-style-position: inside;
  margin-left: 15px;
}
#content .images-area {
	width: 321px; float: left; height: auto; padding: 0px; margin: 0px 2% 20px 0px;
}
#content .images-area > ul {
	width: 313px; list-style: none; margin: auto; padding: 0px;
}
#content .images-area > ul > li {
	width: 102px; height: 59px; float: left; display: block; margin: 1px; position: relative;
}
#content .images-area > ul > li:first-child, #content .images-area > ul.dragging-first-image > li:first-child + li {
	width: 313px; height: 182px; margin-bottom: 3.12%;
}
#content .images-area > ul > li .image-wrapper {
	width: 100px; height: 59px; display: block; text-align: center; font-size: 16px; margin: 0px auto; line-height: 59px;
}
#content .images-area > ul > li:first-child .image-wrapper, #content .images-area > ul.dragging-first-image > li:first-child + li .image-wrapper {
	width: 311px; height: 182px; font-size: 45px; margin: 0px auto; line-height: 170px;
}
img {
	border: 0px;
}
#content .images-area > ul > li .image-wrapper > a > img {
	margin: 0px auto; border: 1px solid rgb(204, 204, 204); position: relative; max-width: 90%; max-height: 100%; vertical-align: middle;
}
#header-images > ul > li > .image-wrapper > img,
#content .subpages .image > a > img,
#content .images-area > ul > li > .image-wrapper > a > img,
#content .images-area > ul > li:first-child > .image-wrapper > a > img,
#content .album-images > ul > li > .image-wrapper > a > img,
#content .related-contents .image > a > img,
#content #content-tag-container .content-tag .image > a > img,
.content-visit-history-pages .image > a > img { border: none; }
#content .images-area > ul > li:first-child .image-wrapper > a > img,
#content .images-area > ul.dragging-first-image > li:first-child + li .image-wrapper > a > img {
	max-width: 96%;
}

#content .images-area > ul > li.no-image {
	visibility: hidden;
}

#content .images-area > ul > li > .image-wrapper .fa-stack {
	position: absolute;
	top: 30%;
	left: 35%;
	opacity: 0.7;
}

#content .images-area > ul > li > .image-wrapper .fa-stack .fa-youtube-play {
	color: black;
}

#content .images-area > ul > li > .image-wrapper .fa-stack .fa-square {
	color: white;
}

#content .images-area > ul > li > .image-wrapper:hover .fa-stack {
	opacity: 1.0;
}

#content .images-area > ul > li > .image-wrapper:hover .fa-stack .fa-youtube-play {
	color: #CD332D;
}

#content .descriptionContainer {
	padding-bottom: 20px;
}

.album-images {
	float: none;
	width: 97.92%;
	padding-bottom:20px;
}

.album-images > ul {
	list-style: none;
}

.album-images > ul > li {
	float: left;
	margin: 1.3%;
	padding: 0.21%;
	width: 260px;
	height: 152px;
	position: relative;
}

.album-images > ul > li.no-image {
	display: none;
}

.album-images > ul > li .image-wrapper {
	width: 260px;
	height: 152px;
	line-height: 152px;
	text-align: center;
	margin: auto;
}

.album-images > ul > li a > img {
	border: 1px solid #ccc;
	vertical-align: middle;
}

.album-images > ul > li a > img.no-image {
	display: none;
}
.cards-container .cards-loader {
  padding: 0;
}
.cards-container .cards-loader > ul {
  list-style: none outside none;
}
.cards-container .cards-loader > ul > li {
  border-radius: 5px;
  float: left;
  margin: 5px 1%;
  padding: 1%;
}
.cards-container .cards-loader > ul > li .cards-image {
  height: 89px;
  text-align: center;
  margin: 0px 0px 3% 0px;
}
.cards-container .cards-loader > ul > li .cards-image img {
  max-width: 100%;
  max-height: 100%;
  vertical-align: middle;
}
.cards-container .cards-loader > ul > li .cards-image img:hover {
  -webkit-filter: brightness(120%);
  filter: brightness(120%);
}
.cards-container .cards-loader > ul > li .cards-title {
  font-weight: bold;
  font-size: 1.2em;
  text-align: center;
}
.cards-container .cards-loader > ul > li .cards-title > a {
  text-decoration: none;
}
.cards-container .cards-loader > ul > li .cards-title > a:hover {
  text-decoration: underline;
}
.cards-container .cards-loader > ul > li .cards-text {
  overflow: auto;
  width: 100%;
}
.cards-container .cards-loader > ul > li .cards-text .cards-description {
  width: 100%;
  word-break: normal;
}
.cards-container .cards-loader > ul > li .cards-text .mCSB_container {
  margin-right: 15px;
}
.cards-container .cards-loader > ul li.cards-during-sort {
  margin: 5px 0px;
}
.cards-container .cards-loader > ul li.cards-first-child {
  margin-left: 0px;
  padding-left: 0px;
}
.cards-container .cards-loader > ul li.cards-last-child {
  margin-right: 0px;
  padding-right: 0px;
}
.cards-container .cards-limit-3 > ul > li {
  width: 30.6%;
}
.cards-container .cards-limit-3 > ul > li .cards-image {
  height: 160px;
  line-height: 160px;
}
.cards-container .cards-limit-3 > ul > li .cards-text {
  max-height: 130px;
}
.cards-container .cards-limit-4 > ul > li {
  width: 22%;
}
.cards-container .cards-limit-4 > ul > li .cards-image {
  height: 110px;
  line-height: 110px;
}
.cards-container .cards-limit-4 > ul > li .cards-text {
  max-height: 120px;
}
.banner-section-container .slick-slider {
  margin-bottom: 0px !important;
}
.banner-section-container .banner-section .banner-section-item.no-url {
  pointer-events: none;
}
.banner-section-container .banner-section .banner-section-item .banner-section-link .banner-section-image {
  width: 100%;
  height: auto;
}
.banner-section-container .banner-section .slick-dots {
  bottom: 20px;
}
.banner-section-container .banner-section .slick-dots li button {
  text-shadow: 2px 2px #fff, -2px -2px #fff, -2px 2px #fff, 2px -2px #fff, 0px 3px #fff, 3px 0px #fff, -3px 0px #fff, 0px -3px #fff;
}
.banner-section-settings {
  text-align: center;
  margin: 0% auto;
  border: 2px solid #000;
  width: 140px;
  background-color: #000;
  border-radius: 5px;
}
.banner-section-settings .banner-section-slideshow-edit-button i {
  background-color: #000;
  color: #fff;
  padding: 5px;
}
.banner-section-settings .banner-section-slideshow-edit-button i:hover {
  background-color: #ffe45c;
  color: #000;
}
.banner-section-settings .banner-section-slideshow-edit-button.disable {
  pointer-events: none;
  opacity: 0.4;
}
#banner-section-change-type-container .banner-section-change-type a.hint {
  display: inline-block;
  padding: 3px 5px;
  margin: 1px;
  font-family: Comic Sans Serif, Arial;
  font-size: 12px;
  line-height: 12px;
  font-weight: bold;
  text-decoration: none;
  border-radius: 5px;
  color: #fff;
  background-color: #ccc;
}
#banner-section-change-type-container .banner-section-change-type a.hint:hover {
  color: #ffe45c;
  background-color: #000;
}
#banner-setting-form {
  width: 920px;
  height: 410px;
  padding: 10px;
}
#banner-setting-form h2 {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #fff;
  background-color: #494949;
  padding: 5px;
  margin: 5px 5px 10px 5px;
  border-radius: 5px 5px 5px 5px;
}
#banner-setting-form .left-panel {
  float: left;
  width: 670px;
}
#banner-setting-form .left-panel .banner-setting-button {
  display: block;
  margin: 10px auto auto auto;
}
#banner-setting-form .left-panel .banner-setting-text-suggestion {
  text-align: center;
  font-size: 9px;
  padding-bottom: 2px;
}
#banner-setting-form .left-panel .banner-setting-text-suggestion a.hint {
  display: inline-block;
  padding: 3px 5px;
  margin: 1px;
  font-family: Comic Sans Serif, Arial;
  font-size: 12px;
  line-height: 12px;
  font-weight: bold;
  text-decoration: none;
  border-radius: 5px;
  color: #fff;
  background-color: #ccc;
}
#banner-setting-form .left-panel .banner-setting-text-suggestion a.hint:hover {
  color: #ffe45c;
  background-color: #000;
}
#banner-setting-form .right-panel {
  float: right;
  width: 230px;
}
#banner-setting-form .rignt-panel .input-form {
  padding: 20px;
}
#banner-setting-form .rignt-panel .input-form .banner-setting-save-cancle-button {
  width: 140px;
  height: 40px;
}
#banner-setting-form .rignt-panel .banner-setting-label-form {
  padding-top: 20px;
}
#banner-setting-form .rignt-panel .banner-setting-select-form {
  padding-bottom: 5px;
}
.banner-setting-image-preview {
  max-width: 100%;
  max-height: 100%;
  margin: 0 auto;
  display: block;
}
.banner-setting-image-mutiple {
  width: 31%;
  height: auto;
  float: left;
  padding: 1%;
}
.banner-setting-image-box-center-vertical {
  height: 200px;
  display: table-cell;
  vertical-align: middle;
}
.banner-setting-image-box-center-horizontal {
  display: block;
  margin: auto;
  height: 200px;
}
.full-width {
  width: 100%;
}#content .webboard, #content .webboard-topic {
  float: left;
  padding: 0px 1.03% 10px;
  width: 78.12%;
  display: block !important;
}
#content .webboard > h1, #content .webboard-topic > h1 {
  padding: 0px;
  margin: 0px;
}
#content .webboard > h1 > span, #content .webboard-topic > h1 > span {
  display: inline-block;
  width: 100%;
}
#content .webboard .info, #content .webboard-topic .info {
  margin: 5px 0px;
  font-size: 12px;
  font-weight: normal;
  color: #000;
}
#content .webboard-topic .description {
  font-weight: normal;
  padding-top: 10px;
  color: #000;
}
#content .webboard-topic .description > img {
  float: right;
  vertical-align: bottom;
  max-width: 50px;
  max-height: 50px;
}
#content .webboard > table {
  min-width: 78.12%;
  width: 100%;
}
#content .webboard > table tr {
  height: 35px;
  padding: 5px 0.66%;
}
#content .webboard > table tr > th {
  padding: 10px 0.36%;
  background-color: #0071ae;
  text-align: center;
  min-width: 60px;
}
#content .webboard > table tr > td {
  border: 1px;
  padding: 10px 0.36%;
  text-align: center;
}
#content .webboard > table tr > th.name, #content .webboard > table tr > td.name {
  text-align: left;
  width: 66.66%;
  max-width: 500px;
}
#content .webboard > table tr td .delete_topic > a {
  background-color: #000;
  background-image: url(/modules/flexi/images/trash-icon.png);
  background-position: 5px center;
  background-repeat: no-repeat;
  border-radius: 3px 3px 3px 3px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.698);
  color: #fff;
  display: block;
  font-size: 1em;
  font-weight: normal;
  margin: 0px;
  padding: 7px 10px;
  text-decoration: none;
  width: 15px;
  text-align: right;
}
#content .webboard > table tr td .delete_topic > a:hover {
  color: #fff;
  background-color: #fed22f;
}
#frm-webboard {
  width: 460px;
  min-height: 250px;
  padding: 10px;
}
#frm-webboard > h2 {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #fff;
  background-color: #494949;
  padding: 5px;
  margin: 5px 0px 10px 0px;
  border-radius: 5px 5px 5px 5px;
}
#frm-topic-create {
  float: left;
  margin-top: -5px;
  padding: 10px;
  width: 450px;
  color: #000;
}
#frm-topic-create .reCaptcha-container {
  overflow: hidden;
  float: left;
}
#frm-topic-create .reCaptcha-container > div {
  transform: scale(0.9);
  -webkit-transform: scale(0.9);
  transform-origin: 0 0;
  -webkit-transform-origin: 0 0;
}
#frm-topic-create .webboard-topic-captcha-error {
  color: red;
}
#frm-topic-create .captcha .error {
  color: red;
}
#frm-topic-create > h2 {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #fff;
  background-color: #000;
  padding: 5px;
  margin: 5px 0px 10px 0px;
  border-radius: 5px 5px 5px 5px;
}
#frm-topic-create input[type=text], #frm-webboard input[type=text] {
  border: 1px solid #bbb;
  border-radius: 4px;
  height: 25px;
  line-height: 25px;
  width: 448px;
  margin-top: 10px;
  margin-bottom: 10px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
#frm-topic-create textarea, #frm-webboard textarea {
  width: 448px;
  height: 120px;
  padding: 0px;
  margin-top: 10px;
  margin-bottom: 10px;
  border: 1px solid #bbb;
  border-top-left-radius: 0.5em;
  border-top-right-radius: 0.5em;
  border-bottom-left-radius: 0.5em;
  border-bottom-right-radius: 0.5em;
  -webkit-border-top-left-radius: 0.5em;
  resize: none;
  /* Safari */
}
#create-topic {
  margin: 10px 0px;
}
#create-topic .button_save, #frm-topic-create .button_save {
  background-color: #ccc;
  border-radius: 5px;
  padding: 5px 15px;
  cursor: pointer;
}
#newboard a {
  background-color: #000;
  background-image: url("/modules/flexi/images/add-button.png");
  background-position: 5px center;
  background-repeat: no-repeat;
  border-radius: 3px 3px 3px 3px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.698);
  color: #fff;
  display: block;
  font-size: 1em;
  font-weight: normal;
  margin: 5px;
  padding: 10px 10px 10px 30px;
  text-decoration: none;
  width: 150px;
  text-align: center;
}
#new_webboard {
  height: 30px;
  width: 90px;
}
#title_topic, #detail_topic, #user_topic, #title_group, #title_detail, #msg_nav_title, #msg_title, #msg_desc {
  color: red;
}
</style>


        <link rel="preload" as="style" onload="this.rel='stylesheet'"  href="/modules/flexi/css/product-category.css?v=4.37.0" />
        <noscript><link rel="stylesheet" href="/modules/flexi/css/product-category.css?v=4.37.0"></noscript>
    


        <link id="cssNoSidebar" rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/no-sidebar.css?v=4.37.0" />
        <noscript><link rel="stylesheet" href="/modules/flexi/css/no-sidebar.css?v=4.37.0"></noscript>
    
        <link id="cssNoLogo" rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/no-logo.css?v=4.37.0" />
        <noscript><link rel="stylesheet" href="/modules/flexi/css/no-logo.css?v=4.37.0"></noscript>
    

            <link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" id="ready-template-style-sheet" media="screen" href="/modules/flexi/ready_template/dynamic_css/dynamic_css.php?page=category&content_id=&v=4.37.0" />
            <noscript><link rel="stylesheet" href="/modules/flexi/ready_template/dynamic_css/dynamic_css.php?page=category&content_id=&v=4.37.0"></noscript>
        
            <link rel="preload" as="style" onload="this.rel='stylesheet'" media="screen" href="/modules/flexi/css/media-query.css?v=4.37.0" />
            <noscript><link rel="stylesheet" href="/modules/flexi/css/media-query.css?v=4.37.0"></noscript>
        <style>
		@media screen and (max-width: 610px) {
			.mobile-topbar{
				display: block;
			}

			#header #topbar {
				display: none;
			}

			#header .header-inner .panel #siteinfo #tagline {
				font-size: 16px;
			}

			#content .hidable-container {
				width: 97.92% !important;
				float: left;
				margin: 0 1.04% 10px;
			}

			#content > .title {
				width: auto;
				float: none;
				clear: both;
			}
			#content .content-tag-title {
				width: 97%;
			}

			#wrapper {
				padding-top: 42px;
				overflow: hidden;
			}

			.subpages .image {
				width: 100%;
				height: 88px;
				margin: 10px 5px 5px;
				line-height: 88px;
				text-align: center;
				font-size: 20px;
				position: relative;
			}

			.subpages .text {
		        overflow: visible;
		    }

			#content .contact-form input[type=text] {
				width: 100%;
				height: 30px;
			}
			#content .contact-form textarea {
				width: 100%;
			}
			#content .contact-form .standard-form ul li label, #content .contact-form .customize-form ul li label {
				  width: 100%;
				  text-align: left;
			}
			#content .contact-form .standard-form ul li i.form-icon {
				right: 1%;
				top: 27px;
			}
			#content .contact-form .customize-form ul li {
				list-style: none;
			}
			#content .contact-form .customize-form ul li i.fa-envelope {
				right: 2%;
				top: 29px;
			}
			#content .contact-form .standard-form, #content .contact-form .customize-form {
				width: 97.92%;
			}
			.subpages .image {
				width: 100%;
				height: 88px;
				margin: 10px 5px 5px;
				line-height: 88px;
				text-align: center;
				font-size: 20px;
				position: relative;
			}

			.subpages .text {
		        overflow: visible;
		    }

			#portlet-related-contents .related-contents > li {
				width: 40%;
				text-align: center;
			}
			#portlet-related-contents .related-contents > li > .image {
				float: none;
				margin: auto;
			}

			#content .images-area {
				width: 100%;
			}

			#content .images-area > ul {
				margin: auto;
				width: 100%;
				max-width: 313px;
			}

			#content .images-area > ul > li {
				width:102px;
				height: 59px;
			}

			#content .images-area > ul > li .image-wrapper {
				margin: 0 auto;
				width: 100px;
				height: 59px;
				line-height: 59px;
				font-size: 16px;
			}

			#content .images-area > ul > li:first-child {
				max-width: 313px;
				width: 100%;
				height: 182px;
				margin: 0 0 3.12%;
			}

			#content .images-area > ul > li:first-child .image-wrapper {
				width: 311px;
				height: 182px;
				margin: 0 auto;
				line-height: 182px;
				font-size: 45px;
			}
		}
	</style>

        <link rel="preload" as="style" onload="this.rel='stylesheet'" href="/modules/flexi/css/full-wrapper-width.css?v=4.37.0" />
        <noscript><link rel="stylesheet" href="/modules/flexi/css/full-wrapper-width.css?v=4.37.0"></noscript>
    

    
    <style>
        #content .hidable-container {
            width: 100% !important;
            margin: 0px 0% 0px;
        }
        #content .hidable {
            margin: 10px 0px 0px;
        }
        .main-section-loader {
            margin: auto 10px;
        }
        .text-section-loader {
            margin: auto 0px;
        }
        .hidable .hidable-content:not(.ready-template-content-section) {
            margin: 10px 1% 20px 1% !important;
        }
        .hidable .ready-template-content-section {
            margin: -11px 0px 0px 0px;
        }
        .hidable .hidable-content:not(.ready-template-content-section).ready-template-slideshow-section-container {
            margin: -11px 0px 0px 0px !important;
        }
        .hidable .hidable-content.banner-section-container {
            margin: -11px 0px 0px 0px !important;
        }

        @media screen and (min-width: 1200px) {
            .hidable .hidable-content#category-contents-container,
            .hidable .hidable-content.articles-section-container {
                margin: 10px auto 20px auto !important;
                max-width: 1200px;
            }
        }
    </style>
    




<script>
/*! loadCSS. [c]2017 Filament Group, Inc. MIT License */
(function(w){
    "use strict";
    var loadCSS = function( href, before, media ){

        var doc = w.document;
        var ss = doc.createElement( "link" );
        var ref;
        if( before ){
            ref = before;
        }
        else {
            var refs = ( doc.body || doc.getElementsByTagName( "head" )[ 0 ] ).childNodes;
            ref = refs[ refs.length - 1];
        }

        var sheets = doc.styleSheets;
        ss.rel = "stylesheet";
        ss.href = href;
        ss.media = "only x";


        function ready( cb ){
            if( doc.body ){
                return cb();
            }
            setTimeout(function(){
                ready( cb );
            });
        }



        ready( function(){
            ref.parentNode.insertBefore( ss, ( before ? ref : ref.nextSibling ) );
        });

        var onloadcssdefined = function( cb ){
            var resolvedHref = ss.href;
            var i = sheets.length;
            while( i-- ){
                if( sheets[ i ].href === resolvedHref ){
                    return cb();
                }
            }
            setTimeout(function() {
                onloadcssdefined( cb );
            });
        };

        function loadCB(){
            if( ss.addEventListener ){
                ss.removeEventListener( "load", loadCB );
            }
            ss.media = media || "all";
        }

        if( ss.addEventListener ){
            ss.addEventListener( "load", loadCB);
        }
        ss.onloadcssdefined = onloadcssdefined;
        onloadcssdefined( loadCB );
        return ss;
    };

    if( typeof exports !== "undefined" ){
        exports.loadCSS = loadCSS;
    }
    else {
        w.loadCSS = loadCSS;
    }
}( typeof global !== "undefined" ? global : this ));

/*! loadCSS rel=preload polyfill. [c]2017 Filament Group, Inc. MIT License */
(function( w ){

    if( !w.loadCSS ){
        return;
    }
    var rp = loadCSS.relpreload = {};
    rp.support = function(){
        try {
            return w.document.createElement( "link" ).relList.supports( "preload" );
        } catch (e) {
            return false;
        }
    };

    rp.poly = function(){
        var links = w.document.getElementsByTagName( "link" );
        for( var i = 0; i < links.length; i++ ){
            var link = links[ i ];
            if( link.rel === "preload" && link.getAttribute( "as" ) === "style" ){
                w.loadCSS( link.href, link, link.getAttribute( "media" ) );
                link.rel = null;
            }
        }
    };


    if( !rp.support() ){
        rp.poly();
        var run = w.setInterval( rp.poly, 300 );
        if( w.addEventListener ){
            w.addEventListener( "load", function(){
                rp.poly();
                w.clearInterval( run );
            } );
        }
        if( w.attachEvent ){
            w.attachEvent( "onload", function(){
                w.clearInterval( run );
            } );
        }
    }
}( this ));
</script>

<style>
#ve-loading-overlay {
    z-index: 999;
    background-color: #ffffff;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    position: fixed;
}
</style>

<script defer type="text/javascript" src="/modules/flexi/js/velaeasy/i18n/vi.js"></script>
 

<script>
    document.addEventListener('lazybeforeunveil', function(e){
        var bg = e.target.getAttribute('data-bg');
        if(bg){
            e.target.style.backgroundImage = 'url(' + bg + ')';
        }
    });
</script>
<script defer type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script defer type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
<script defer type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.2/jquery.ui.touch-punch.min.js"></script>
<script defer type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/qtip2/2.2.0/jquery.qtip.min.js"></script>
<script defer type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.33/jquery.colorbox-min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.browser/jquery.browser.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.tosrus/jquery.tosrus.min.all.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.lightbox2/dist/js/lightbox.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.base64/jquery.base64.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.simplePagination/jquery.simplePagination.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/punycode-js/punycode.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/sprintf/sprintf-0.6.min.js"></script>
<!--[if lt IE 9]>
<script defer type="text/javascript" src="/modules/flexi/js/html5shiv/html5shiv.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script defer type="text/javascript" src="/modules/flexi/js/css3-media-queries/css3-mediaqueries.js"></script>
<![endif]-->
<script defer type="text/javascript" src="/modules/flexi/js/lazysizes/lazysizes.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/jquery.dropdown/jquery.dropdown.min.js"></script>
<script defer type="text/javascript" src="/modules/flexi/js/velaeasy/always.min.js?v=4.37.0"></script>
<script>
    window.addEventListener('DOMContentLoaded', function() {
        $(document).ready(function() {
            veMain.init("eyJmdWxsX3NpdGUiOnRydWUsImRlYnVnIjpmYWxzZSwidGFnX2Nsb3VkIjpmYWxzZSwicGhvbmVGb3JtYXQiOiJUaGFpIiwiZnJlZV9iYW5uZXJfdXJsIjoiaHR0cHM6XC9cL3d3dy5yZWFkeXBsYW5ldC5hc2lhXC8xODI4NDhcL3Itd2ViXC8/dXRtX3NvdXJjZT1yd2ViX2ZyZWUmdXRtX21lZGl1bT10b3BfYmFubmVyJnV0bV9jYW1wYWlnbj1vcGVud2Vidm4iLCJmZWF0dXJlcyI6eyJkaXNrX3F1b3RhX2luX01CIjoiMTAwIiwicGhvdG9fYWxidW0iOiI5OTkiLCJ3ZWJib2FyZCI6IjAiLCJzaG9wcGluZ19jYXJ0IjoiMCIsInZlbGFoYW5keSI6IjAiLCJtZW1iZXJzaGlwIjoiMSIsInNwZWNpYWxfcHJpY2UiOiIwIiwidGFnZ2luZyI6IjEiLCJyZWxhdGVkX2NvbnRlbnRzIjoiMSIsInZpc2l0X2hpc3RvcnkiOiIxIiwiZmJfcGFnZV90YWIiOiIxIiwic2xpZGVzaG93IjoiMCIsImNoYXQiOiIwIiwic2FsZXNfcmVwb3J0IjoiMCIsInNoaXBwaW5nIjoiMCIsInN0b2NrIjoiMCIsInJlYWR5X3RlbXBsYXRlIjoiMSIsIm9yZGVyX3Byb2R1Y3RzX3JlcG9ydCI6IjAiLCJjb250ZW50IjoiNSIsIm1lbWJlciI6IjEwMDAwIiwic2xpZGVzaG93djIiOiIwIiwiYmFubmVyX3NlY3Rpb24iOiIyMCIsInJwc2hvcCI6IjEiLCJycHNob3BfcHJvZHVjdHMiOiI1IiwicnBzaG9wX3Byb2R1Y3RfdmFyaWFudHMiOiIwIiwib3JkZXJfbWFuYWdlbWVudCI6IjEiLCJvbWlzZSI6IjAiLCJzYWxlc2Rlc2siOiIxIiwicGF5cGFsIjoiMCIsImNvbnRhY3RfcHVyY2hhc2UiOiIxIiwiY3VzdG9tX2Zvcm0iOiIxIn0sImZiX3BhZ2VfdGFiIjowLCJkb21haW4iOiJ3NTQwMjM1MDMucmVhZHlwbGFuZXQuc2l0ZSIsImxhbmd1YWdlIjoiVkkiLCJtb2RlIjoiIiwicGFnZSI6ImNhdGVnb3J5IiwiY29udGVudF9pZCI6IiIsImhvbWVfY29udGVudF9pZCI6IjE3NDc0MDAxIiwid2ViYm9hcmRfaWQiOiIiLCJ3ZWJib2FyZF90b3BpY19pZCI6IiIsIm1vYmlsZV9zaXRlIjoiMSIsImNvbnRlbnRfdHlwZSI6IiIsInN0eWxlX3Nsb3QiOiIxIiwibm9fcmNsaWNrX21vZGUiOiJub25lIiwibm9fcmNsaWNrX2FsZXJ0IjoiMCIsIm5vX3JjbGlja19tc2ciOiJLaFx1MDBmNG5nIGNobyBwaFx1MDBlOXAgbmhcdTFlYTVwIHBoXHUxZWEzaSIsIndyYXBwZXJfd2lkdGgiOiJmdWxsIiwic2l0ZW5hbWVfZm9udF9zaXplIjoiIiwidGFnbGluZV9mb250X3NpemUiOiIiLCJzdGlja3lfdG9wYmFyIjoiMSIsIm1lbnVfYmdfc2ltcGxlIjoiMSIsInVzZXJfc3RvY2siOiIwIiwicmVDYXB0Y2hhX3NpdGVLZXkiOiI2TGVVd1NRVEFBQUFBQ0RKN2h2U00ybndISnhUNHNMYkRFOTcyQzlKIiwicmVDYXB0Y2hhX2VuYWJsZSI6IjEiLCJtZW1iZXJfbG9naW4iOiIiLCJkZXNrdG9wX21vZGUiOiIwIiwicnBzaG9wX2VuYWJsZSI6IjEiLCJoZWFkZXJfbG9nb19vbl9zdGlja3lfdG9wYmFyIjoiMSIsInNob3dfdG9wYmFyX2xvZ28iOiIxIiwicmVnaXN0ZXJfY291bnRyeSI6IlZOIiwiaXNfcm1wIjowfQ==");
        });

        // load the background image after everything else is loaded
        $(window).load(function(){
            veMain.bgLoad();
        });
    });
</script>
<script defer type="text/javascript" src="/modules/flexi/js/velaeasy/product-category.min.js?v=4.37.0"></script>
<script>
                        window.addEventListener('DOMContentLoaded', function() {veProductCategory.init("eyJwYWdlX2NvdW50IjoxLCJwYWdlIjoxLCJsaW1pdCI6MjQsInByb2R1Y3RzX2NvdW50IjowLCJzZWxlY3RlZF9vcHRpb24iOiIifQ==");});
                    </script>
<!-- START: Google Analytics -->

<!-- END: Google Analytics -->

<script defer src="https://www.google.com/recaptcha/api.js?onload=reCaptchaOnloadCallback&hl=vi&render=explicit"></script>
    </head>
        <body itemscope itemtype="http://schema.org/WebPage" style="" >
        <div id="ve-loading-overlay">
            <img src="/modules/flexi/images/ajax-loading.gif" />
        </div>

    	<!-- Start Shappy Chat -->
    			<!-- End Shappy Chat -->

        
        <!-- This following dummy element is for support a Theme Impoter to get a value of menu_bg_simple only -->
        <span id="menu_bg_simple_dummy" class="menu-bg-simple-1"></span>

        <div id="body-bg" class="body-use-salesdesk">
            
<div id="slidemenu-container">
    <div id="slidemenu-menu">
        <nav>
            <ul class="slidemenu">
                <li class="slidemenu-back main">
                    <i class="fa fa-reply fa-2x"></i>
                    <a href="#" id="main-back"> Quay lại</a>
                </li>
                                        <li id="nav-17474001" class="nav-content"             data-seo-friendly="/17474001/trang-chủ">
            <a href="/" ><div>Trang chủ</div></a>

            <ul class="subnav"></ul>        <li id="nav-17473997" class="nav-content"             data-seo-friendly="/17473997/giới-thiệu">
            <a href="/17473997/giới-thiệu" ><div>Giới thiệu</div></a>

            <ul class="subnav"></ul>        <li id="nav-17473999" class="nav-content"             data-seo-friendly="/17473999/dịch-vụ">
            <a href="/17473999/dịch-vụ" ><div>Dịch vụ</div></a>

            <ul class="subnav">        <li id="nav-17474000" class="nav-content"             data-seo-friendly="/17474000/bài-viết">
            <a href="/17474000/bài-viết" ><div>Bài viết</div></a>

            <ul class="preload-subnav"></ul></ul>        <li id="nav-17474048" class="nav-category"             >
            <a href="/category/95538" target='_self'><div>Đăng nhập</div></a>

            <ul class="subnav"></ul>                <li class="blank"></li>
                            </ul>
        </nav>
    </div>
    <div id="slidemenu-cover"></div>
</div>

                <div class="back-to-top">
                            </div>
                        <div id="banner-festival" class="has-ads-no-banner" style=display:none;>
                            </div>


            <div id="wrapper" >
                                                        <div id="ads" class="vn">
                                                            <a href="javascript: void(0)" class="desktop banner">
                        <span class="content">
                            <span class="text">
                                Website này xây dựng từ hệ thống                                <img src="/modules/flexi/images/ReadyPlanet_Logo.png" class="logo"/>
                                Xây dựng website của bạn                            </span>
                            <span class="button">Miễn phí</span>
                        </span>
                    </a>
                    <a href="javascript: void(0)" class="mobile banner">
                        <span class="content">
                            <span class="text">Xây dựng website của bạn</span>
			                <span class="button">Miễn phí</span>
                        </span>
                    </a>
                                    </div>
                                                        <div class="mobile-topbar has-ads" >
                        <div class="trigger-wrapper">
                            <a id="slidemenu-trigger" title="Menus">
                                <i class="icon-trigger_wrapper"></i>
                            </a>
                        </div>
                                                    <div class="slidemenu nav-topbar-logo">
                                <a href="/" id="slidemenu-topbar-logo">
                                    <img src="/images/logo/medium-1581925981957.jpg" id="topbar-logo-image">
                                </a>
                            </div>
                                                    <div class = "searchbox-wrapper has-rp-cart ">
                                <div class="search-form">
                                    <form class="contact product-search">
                                        <div class="input-wrap">
                                            <a id = "mobile-clear-icon">
                                                <i class = "fa fa-times"></i>
                                            </a>
                                            <input id="mobile-search-input" type="search" class="keyword" name="keyword-mobile"/>
                                        </div>
                                    </form>
                                </div>
                                <a id = "mobile-searchbox-icon">
                                    <i class = "icon-search"></i>
                                </a>
                            </div>
                                                    <!--<rp-cart-button class="rp-cart-button"></rp-cart-button>-->
                            <span class="ve-cart-button">
                                <span class="ve-cart-button-flex-item">
                                    <span class="ve-icon">
                                        <i class="fa fa-lg fa-shopping-cart"></i>
                                    </span>
                                    <span class="ve-cart-count">0</span>
                                </span>
                            </span>
                                                </div>
                                            <div id="header" class="has-ads-no-banner">
                                    <div id="topbar" class="topbar-logo-medium topbar-logo-active has-ads-no-banner">
                
<div class="topbar-sub-container">

    <div class="image nav-topbar-logo " style="">
        <a href="/" id="topbar-logo">
            <img src="/images/logo/medium-1581925981957.jpg" id="topbar-logo-image">
        </a>
    </div>    
    <div class="topnav-container">
        <ul class="nav topnav top-menu-position-right">
                <li id="nav-17474001" class="nav-content"             data-seo-friendly="/17474001/trang-chủ">
            <a href="/" ><div>Trang chủ</div></a>

            <ul class="subnav"></ul>        <li id="nav-17473997" class="nav-content"             data-seo-friendly="/17473997/giới-thiệu">
            <a href="/17473997/giới-thiệu" ><div>Giới thiệu</div></a>

            <ul class="subnav"></ul>        <li id="nav-17473999" class="nav-content"             data-seo-friendly="/17473999/dịch-vụ">
            <a href="/17473999/dịch-vụ" ><div>Dịch vụ</div></a>

            <ul class="subnav">        <li id="nav-17474000" class="nav-content"             data-seo-friendly="/17474000/bài-viết">
            <a href="/17474000/bài-viết" ><div>Bài viết</div></a>

            <ul class="preload-subnav"></ul></ul>        <li id="nav-17474048" class="nav-category"             >
            <a href="/category/95538" target='_self'><div>Đăng nhập</div></a>

            <ul class="subnav"></ul>        </ul>
    </div>
    <div class="topnav-component   count-icon-2">
        <a class= "topnav-searchbox-icon">
            <i class ="fa fa-lg fa-search"></i>
        </a>
        <!--<rp-cart-button class="rp-cart-button"></rp-cart-button>-->
    <span class="ve-cart-button">
        <span class="ve-icon">
            <i class="fa fa-lg fa-shopping-cart"></i>
        </span>
        <span class="ve-cart-count">0</span>
    </span>
            </div>
</div>
<div class="topnav-searchbox hide">
    <div class="topnav-searchbox-container">
    <input type="textbox" id="topnav-searchbox-input" name="keyword-topnav" placeholder="Tìm kiếm">
    </div>
</div>
                <div class="clear"></div>
            </div>
             
<div class="header-inner-separator clear"></div> 
     	<style>
           #header .header-inner  {
           		height: 0px;
           }
        </style>
    
    <div class="header-inner header-height-zero">
        <div class="ready-template-panel ready-template-header-background "  >
                </div>

    </div>
<div class="clear"></div>

                    </div>
                                                <div id="content" class="has-ads"  itemscope itemtype="http://schema.org/Article" >
                    
                    <h1 class="product-title">


<span  itemprop="name" ></span>
</h1>

<div class="hidable-container"><p class="product-detail-product-not-found">Không tìm thấy danh mục sản phẩm này</p>
</div>
                    <div class="clear"></div>

                </div>

                
                                                    
                                    <div id="footer">
                                <div id="footer-text">
            
            Trường Đại học Kinh tế Đà Nẵng - 71 Ngũ Hành Sơn TP Đà Nẵng - Website: www.due.edu.vn                </div>
                        </div>
                
                
                
                                    <div id="powered-by">
                        <a href="https://www.readyplanet.asia/182848/r-web/?utm_source=rweb&utm_medium=powered_by&utm_campaign=openwebvn" target="_blank">
    <img src="/modules/flexi/images/powered-by-v3.png"
         alt="Powered by ReadyPlanet"
         title="Powered by ReadyPlanet" />
</a>
                    </div>
                            </div>
        </div> <!-- #body-bg -->

        <script src="https://cdn.omise.co/omise.js"></script>
<rp-cart
    public-token="52102e34053c65afd74a9219f45c298d"
    locale="vi"
    primary-main-color="#ffffff"
    primary-sub-color="#3b3b3b"
    secondary-main-color="#63acff"
    secondary-sub-color="#ffffff"
            gclid=""
    global-font="Kanit"
    open-modal="0"
    >
</rp-cart>

<link rel="stylesheet" href="https://s3-ap-southeast-1.amazonaws.com/static.readyplanet.net/rpshop-cart/lastest/static/css/app.css" />
<!-- <script src="?v=4.37.0"></script> -->
<script src="https://s3-ap-southeast-1.amazonaws.com/static.readyplanet.net/rpshop-cart/lastest/static/js/manifest.js?v=4.37.0"></script>
<script src="https://s3-ap-southeast-1.amazonaws.com/static.readyplanet.net/rpshop-cart/lastest/static/js/vendor.js?v=4.37.0"></script>
<script src="https://s3-ap-southeast-1.amazonaws.com/static.readyplanet.net/rpshop-cart/lastest/static/js/app.js?v=4.37.0"></script>


<script src="https://www.paypalobjects.com/api/checkout.js"></script>


<div id="header-language-switcher-dropdown" 
    class="jq-dropdown jq-dropdown-anchor-right jq-dropdown-tip"
>
    <ul class="jq-dropdown-menu">
            </ul>
</div>
<script id="r-widget-script" src="https://rwidget.readyplanet.com/widget/widget.min.js?business_id=65f534d68dce0776d7b58be53599f8eb" type="text/javascript" charset="UTF-8"></script>        <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "https://api-rmp.readyplanet.com/js/rmp-widget.min.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'rmp_widget_js'));
        </script>
    </body>
</html>
